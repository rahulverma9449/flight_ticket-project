// import { NetworkType } from "@Enum/NetworkType"

// export type ILoginLoad = {
//     mobile_number: string
// }

// export type IVerifyOtpLoad = {
//     mobile_number: string
//     otp: string
//     user_type: string
// }

// export type IGstValidationLoad = {
//     gst_number: string;
// }

// export type IPanValidationLoad = {
//     pan_number: string;
// }

// export type IRegisterShipperLoad = {
//     fullname: string;
//     business_category: string;
//     email: string;
//     mobile_number: string;
// }

// export type IAddAddress = {
//     shipperId: string;
//     addressType: string;
//     addressName: string;
//     latitude: string;
//     longitude: string;
//     addressLine1: string;
//     addressLine2: string;
//     landMark: string;
//     city: string;
//     state: string;
//     pinCode: string;
// }

// export type IUpdateAddress = Omit<IAddAddress, "latitude" | "longitude"> & {
//     id: string
// }


// export type IInviteRequestLoad = {
//     mobileNo: string,
//     transportarName: string,
//     status: string,
//     userId: string
// }

// export type ICancelOrder = {
//     orderId: string | number
//     parentOrderId: string | number
//     weight: string | number
// }

// export interface IAssignCarrierRequestToOrderByShipper {
//     orderId: number;
//     carrier_id: string;
//     origin: string;
//     destination: string;
//     carrier_name: string;
//     is_KYC_verified: boolean;
//     carrier_mobile_number: string;
//     commodity: string;
//     commodity_type: string
//     tripType: string;
//     carrier_notification_id: string;
//     status: string;
//     userType: string;
//     selected_truck: string;
//     driver_number: string;
//     driver_name: string;
//     dispatch_date: string;
//     weight: string;
//     targetRate: string;
//     finalRate: string;
//     remarks: string;
//     order_date: string;
//     originLocation: OriginLocationOrDestinationLocation;
//     destinationLocation: OriginLocationOrDestinationLocation;
//     shipper_id: string;
//     shipper_name: string;
//     shipper_type: string;
//     shipperAgentCode: string;
//     shortage: string;
//     loading: string;
//     unloading: string;
//     tripal: string;
//     networkType: NetworkType;
//     dispatchNumber: string
// }
// interface OriginLocationOrDestinationLocation {
//     latitude: number;
//     longitude: number;
// }




