export interface IKycDetail {
    business_address: BusinessAddress;
    operational_address: OperationalAddress;
    operations_poc: OperationsPoc;
    pan_details: PanDetails;
    gst_details: GstDetails;
    owner_number: string;
    additional_number: string;
    email?: null;
    company_name?: null;
    business_type: string;
    aadhaar_number?: null;
    business_category?: null;
    personal_pan_photo: string;
    aadhaar_photo: string;
    fullname: string;
    aadhaar_photo2?: null;
    business_registration: string;
    _id: string;
    commodity_type?: (CommodityTypeEntity)[] | null;
    finance_poc?: (DispatchEntityOrTraderEntityOrFinancePocEntity)[] | null;
    updatedAt: string;
    kyc_id: string;
    createdAt: string;
    __v: number;
    is_KYC_verified: boolean;
    is_KYC_completed: boolean;
    is_KYC_blocked: boolean;
}
interface BusinessAddress {
    business_name: string;
    owner_first_name?: null;
    owner_last_name?: null;
    address: string;
    city: string;
    state: string;
    pin_code: string;
}
interface OperationalAddress {
    address: string;
    city: string;
    state: string;
    pin_code: string;
}
interface OperationsPoc {
    dispatch?: (DispatchEntityOrTraderEntityOrFinancePocEntity)[] | null;
    trader?: (DispatchEntityOrTraderEntityOrFinancePocEntity)[] | null;
}
interface DispatchEntityOrTraderEntityOrFinancePocEntity {
    number: string;
    _id: string;
    name?: string
}
interface PanDetails {
    pan_number: string;
}
interface GstDetails {
    gst_no: string;
}
interface CommodityTypeEntity {
    name: string;
    _id: string;
}
