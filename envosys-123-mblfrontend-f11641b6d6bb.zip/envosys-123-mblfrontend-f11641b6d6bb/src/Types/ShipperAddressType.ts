import { IApiMessage } from "./ApiResponseType";

export interface IShipperAddress extends IApiMessage {
    data: (DataEntity)[];
}
export interface DataEntity {
    shipperId?: string | null;
    addressType?: string | null;
    addressName?: string | null;
    facilityName?: string | null;
    latitude?: null;
    longitude?: null;
    addressLine1?: string | null;
    addressLine2?: string | null;
    landMark?: string | null;
    city?: string | null;
    state?: string | null;
    pinCode?: string | null;
    _id: string;
    createdAt: string;
    updatedAt: string;
    __v: number;
}



