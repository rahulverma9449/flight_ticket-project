export interface Register_Shipper extends IApiMessage {
    user: User;
    token: string;
}
export interface User {
    pan_details: PanDetails;
    location: Location;
    first_name?: null;
    last_name?: null;
    fullname: string;
    referral_code: string;
    createdByName: string;
    assignedTo: string;
    assignedToName: string;
    image: string;
    transferedFrom?: null;
    email: string;
    deleted_by_admin: boolean;
    isRegistered: boolean;
    is_KYC_completed: boolean;
    is_KYC_verified: boolean;
    is_KYC_blocked: boolean;
    profile: string;
    business_category: string;
    is_tds_excluded: boolean;
    company_name: string;
    user_role: string;
    mobile_number: string;
    notification_id?: null;
    wallet_code?: null;
    isWalletAdded: boolean;
    isWalletPinAdded: boolean;
    cashLimit: number;
    advancePercentage: number;
    status?: null;
    rating?: null;
    dispatchName?: null;
    dispatchNumber?: null;
    commodity?: null;
    locality?: null;
    prefferedState?: null;
    prefferedState1?: null;
    _id: string;
    userId: string;
    agents?: (null)[] | null;
    createdAt: string;
    updatedAt: string;
    __v: number;
    kyc_id: string;
    networkTranport?: (null)[] | null;
    origin?: (null)[] | null;
    destination?: (null)[] | null;
}

export type IApiMessage = {
    type: "success" | "",
    message: string
}

export type IVerifyOtp = INotRegisteredLogin | IRegisteredLogin;

type INotRegisteredLogin = IApiMessage & {
    isRegistered: false;
    mobile_number: string;
    is_KYC_completed: boolean;
    is_KYC_verified: boolean;
}


type IRegisteredLogin = IApiMessage & {
    isRegistered: true;
    token: string;
    deleted_by_admin: boolean;
    mobile_number: string;
    is_KYC_completed: boolean;
    is_KYC_verified: boolean;
    user?: (UserKycNotVerifiedEntity)[] | null;
}
interface UserKycNotVerifiedEntity {
    pan_details: PanDetails;
    location: Location;
    first_name?: string;
    last_name?: string;
    fullname: string;
    referral_code: string;
    createdByName: string;
    assignedTo: string;
    assignedToName: string;
    image: string;
    transferedFrom?: null;
    email: string;
    deleted_by_admin: boolean;
    isRegistered: boolean;
    is_KYC_completed: boolean;
    is_KYC_verified: boolean;
    is_KYC_blocked: boolean;
    profile: string;
    business_category: string;
    is_tds_excluded: boolean;
    company_name: string;
    user_role: string;
    mobile_number: string;
    notification_id?: null;
    wallet_code?: null;
    isWalletAdded: boolean;
    isWalletPinAdded: boolean;
    cashLimit: number;
    advancePercentage: number;
    status?: null;
    rating?: null;
    dispatchName?: null;
    dispatchNumber?: null;
    commodity?: null;
    locality?: null;
    prefferedState?: null;
    prefferedState1?: null;
    _id: string;
    userId: string;
    agents?: any[] | null;
    origin?: any[] | null;
    destination?: any[] | null;
    createdAt: string;
    updatedAt: string;
    __v: number;
}
interface PanDetails {
    pan_number?: any;
}
interface Location {
    latitude?: any;
    longitude?: any;
}




/**
 * Carrier Request By Lane Api Respose
 */
export interface CarrierRequestByLaneResponse {
    loadPost?: (LoadPostEntity)[] | null;
    type: string;
}
export interface LoadPostEntity {
    _id: string;
    orderId: number;
    CanceledBy?: null;
    __v: number;
    accountName?: null;
    accountNumber?: null;
    advancePaymentForTypeRemark?: null;
    advancePercentage: number;
    ag_Commision: number;
    ag_Margin: number;
    balancePaymentForTypeRemark?: null;
    beneficiaryName?: null;
    billCopy?: null;
    broker_Commision: number;
    calculatedAdvance: number;
    calculatedBalance: number;
    cancelRemarks?: null;
    carrierAdvanceRemark?: null;
    carrierAgentCode?: null;
    carrierBalanceRemark?: null;
    carrierFinalRate: number;
    carrierFinalremark: string;
    carrierRequestUpdate: string;
    carrier_quotations?: (null)[] | null;
    carrier_visibility: boolean;
    fullFillmentWeight: string
    cash: number;
    commission: number;
    commodity: string;
    commodityType: string;
    consigneeInvoice?: null;
    consignerInvoice?: null;
    createdAt: string;
    createdBy?: null;
    createdByUserType: string;
    deduction: number;
    deductionType?: null;
    destination: string;
    destinationLocation: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    detentionAmount: number;
    dispatchDate: string;
    dispatchTime?: null;
    driverInvoice?: null;
    driverLastLocation: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    driverName?: null;
    driverNumber?: null;
    driverStartLocation: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    finalRate: number;
    foAdvanceAmount: number;
    foAdvanceFixedAmount: number;
    foAdvancePaymentStatus?: null;
    foAdvancePercentage: number;
    foAdvanceRemainigAmount: number;
    foAdvancepercentageRemark: string;
    foAgConvenienceFee: number;
    foBalancePending: number;
    foCashback: number;
    foFinalRate: number;
    foInstantCashAmount: number;
    foIsAdvanceFixed: boolean;
    foPayments?: (null)[] | null;
    foTdsAmount: number;
    foTdsPercentage: number;
    foTotalFreight: number;
    foTotalPaybaleAdvance: number;
    fofinalBalance: number;
    freight_Difference: number;
    ifscCode?: null;
    invoiceGenerated: boolean;
    invoiceNumber?: null;
    invoiceUploaded: boolean;
    invoiceUrl?: null;
    invoiceVerified: boolean;
    isFoSettingSave: boolean;
    isFullPay: boolean;
    isPodUploaded: boolean;
    isSamunnatiPayment: boolean;
    loading: string;
    loadpost_assigned_carrier_id?: null;
    maskedDestination: string;
    maskedOrigin: string;
    offlineInvoicePrinted: boolean;
    orderDate: string;
    orderStatus: string;
    ordertrack?: (null)[] | null;
    origin: string;
    originLocation: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    panNumber?: null;
    parentOrderId?: null;
    paymentForType?: null;
    payments?: (PaymentsEntity)[] | null;
    podAdditional1Url?: null;
    podAdditional2Url?: null;
    podArrivedUrl?: null;
    podComment?: null;
    podConfirmStatus?: null;
    podFeedback?: null;
    podReceiptUrl?: null;
    podUploadedBy?: null;
    podUrl?: null;
    remarkNotes?: (null)[] | null;
    remarks: string;
    reschduledAttempt: number;
    saveDetentionDeduction: boolean;
    shipperAgentCode: string;
    shipperBalanceWithOutDeductions: number;
    shipperId: string;
    shipperName: string;
    shipperType: string;
    shipper_Commision: number;
    shipperfinalBalance: number;
    shortage: string;
    targetRate: number;
    tdsAmount: number;
    tdsPercentage: number;
    totalCommissionremark: string;
    total_Commision: number;
    track?: (null)[] | null;
    tripType: string;
    tripal: string;
    unloading: string;
    updatedAt: string;
    vehicleNumber?: null;
    weighingSlip?: null;
    weight: number;
    weightActual: number;
    CarrierRequestData?: (CarrierRequestDataEntity)[] | null;
    SubOrderData?: (SubOrderDataEntity | null)[] | null;
}
interface TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation {
    latitude: number;
    longitude: number;
}
interface PaymentsEntity {
    amount: number;
    hash?: null;
    paidAmount: number;
    adjustAmount: number;
    balanceAdjustAmount: number;
    transactionId?: null;
    bankDetails?: null;
    paymentStatus?: null;
    chequeNumber?: null;
    chequeUrl?: null;
    transactionUrl?: null;
    transactionRemark?: null;
    payLaterFlag: boolean;
    payLaterComment?: null;
    _id: string;
    paymentType: string;
    transactionHistory?: (null)[] | null;
}
interface CarrierRequestDataEntity {
    _id: string;
    originLocation: OriginLocationOrDestinationLocation;
    destinationLocation: OriginLocationOrDestinationLocation;
    origin: string;
    destination: string;
    commodity: string;
    tripType: string;
    dispatchDate: string;
    isDeleted: boolean;
    loadRequest?: (LoadRequestEntity)[] | null;
    createdAt: string;
    updatedAt: string;
    __v: number;
    totalrequest: number;
}
interface OriginLocationOrDestinationLocation {
    latitude: string;
    longitude: string;
}
export interface LoadRequestEntity {
    carrier_Name: string;
    mobileNumber: string;
    matricTon?: (string)[] | null;
    is_KYC_verified: boolean;
    isActive: boolean;
    createdAt: string;
    shortage: string;
    loading: string;
    unloading: string;
    tripal: string;
    _id: string;
    carrier_id: string;
    notification_id: string;
    requestStatus: string;
    truckDetails?: (TruckDetailsEntity)[] | null;
    requestCreatedBy: string;
    preference_of_Shipper?: (PreferenceOfShipperEntity)[] | null;
    CarrierDetails?: (CarrierDetailsEntity)[] | null;
}
export interface TruckDetailsEntity {
    vehicleNumber: string;
    driverNumber: string;
    driverName: string;
    truckWeight: string;
    availableStatus: boolean;
    orderId?: number | null;
    createdAt: string;
    _id: string;
}
interface PreferenceOfShipperEntity {
    shipperName: string;
    shipperId: string;
    _id: string;
}
interface CarrierDetailsEntity {
    transporter: Transporter;
    driver: Driver;
    location: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    profileType: string;
    owner_name: string;
    mobile_number: string;
    referral_code: string;
    createdByName: string;
    image: string;
    address?: null;
    company_name?: string;
    number_of_trucks: string;
    truck_count_type: string;
    isCarrierAccept: boolean;
    notification_id: string;
    isRegistered: boolean;
    deleted_by_admin: boolean;
    is_KYC_completed: boolean;
    is_KYC_verified: boolean;
    kyc_UpdatedBy: string;
    kyc_UpdatedOn: string;
    is_KYC_in_review: boolean;
    is_tds_excluded: boolean;
    is_pvt_ltd: boolean;
    assignedTo: string;
    assignedFrom: string;
    status?: null;
    email?: null;
    whatsAppNumber?: null;
    carrierType?: null;
    locality: string;
    loadTo?: null;
    loadFrom?: null;
    primaryLane?: null;
    secondaryLane?: null;
    truckOwned?: null;
    truckWeight?: null;
    appStatus?: null;
    isRcIdVerified?: null;
    isPanBankVerified?: null;
    lastLoginDate: string;
    mobileId: string;
    _id: string;
    user_id: string;
    lanes?: (null)[] | null;
    vehicles?: (VehiclesEntity)[] | null;
    origin?: (OriginEntityOrDestinationEntity)[] | null;
    destination?: (OriginEntityOrDestinationEntity)[] | null;
    createdAt: string;
    updatedAt: string;
    __v: number;
    kyc_id: string;
}
interface Transporter {
    companyName: string;
    transporterName: string;
    transporterLocality: string;
}
interface Driver {
    trackDriver: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    rc_number: string;
    driver_name: string;
    owner_number: string;
    rc_image_url: string;
    rc_image_url_back: string;
    dl_image_url: string;
    is_rc_data_unavailable: boolean;
}
interface VehiclesEntity {
    origin: OriginOrDestination;
    destination: OriginOrDestination;
    deleted: boolean;
    first_truck: boolean;
    truck_number?: string | null;
    no_of_tyres?: string | null;
    is_rc_data_unavailable: boolean;
    rc_image_url?: null;
    rc_image_url_back?: null;
    location?: null;
    owner_number: string;
    owner_name: string;
    vehicleType: string;
    manufacturer: string;
    address: string;
    modal: string;
    regExpiry: string;
    fuleType: string;
    regDate: string;
    IsTruckValid: boolean;
    _id: string;
    rc_number: string;
}
interface OriginOrDestination {
    name?: null;
}
interface OriginEntityOrDestinationEntity {
    _id: string;
    name: string;
    latitude: number;
    longitude: number;
}
interface SubOrderDataEntity {
    originLocation: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    destinationLocation: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    driverStartLocation: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    driverLastLocation: TrackDriverOrLocationOrOriginLocationOrDestinationLocationOrDriverStartLocationOrDriverLastLocation;
    orderDate: string;
    parentOrderId: number;
    shipperName: string;
    shipperType: string;
    origin: string;
    destination: string;
    commodity: string;
    commodityType: string;
    reschduledAttempt: number;
    dispatchTime?: null;
    weight: number;
    weightActual: number;
    tripType: string;
    targetRate: number;
    finalRate: number;
    carrierFinalRate: number;
    orderStatus: string;
    remarks: string;
    carrierAdvanceRemark?: null;
    carrierBalanceRemark?: null;
    vehicleNumber: string;
    driverNumber: string;
    driverName: string;
    maskedOrigin: string;
    maskedDestination: string;
    carrier_visibility: boolean;
    loadpost_assigned_carrier_id: string;
    carrierRequestUpdate: string;
    createdByUserType: string;
    advancePercentage: number;
    isFullPay: boolean;
    commission: number;
    cash: number;
    tdsPercentage: number;
    tdsAmount: number;
    calculatedAdvance: number;
    calculatedBalance: number;
    shipperBalanceWithOutDeductions: number;
    foFinalRate: number;
    foIsAdvanceFixed: boolean;
    foAdvanceFixedAmount: number;
    foAdvancePercentage: number;
    foAgConvenienceFee: number;
    foCashback: number;
    foTdsPercentage: number;
    foAdvanceAmount: number;
    foInstantCashAmount: number;
    foTdsAmount: number;
    foTotalFreight: number;
    foBalancePending: number;
    foTotalPaybaleAdvance: number;
    freight_Difference: number;
    shipper_Commision: number;
    ag_Margin: number;
    total_Commision: number;
    ag_Commision: number;
    broker_Commision: number;
    carrierFinalremark: string;
    totalCommissionremark: string;
    foAdvancepercentageRemark: string;
    shortage: string;
    loading: string;
    unloading: string;
    tripal: string;
    shipperfinalBalance: number;
    fofinalBalance: number;
    foAdvanceRemainigAmount: number;
    foAdvancePaymentStatus?: null;
    isFoSettingSave: boolean;
    deduction: number;
    detentionAmount: number;
    podComment?: null;
    podFeedback?: null;
    podConfirmStatus?: null;
    deductionType?: null;
    invoiceUrl?: null;
    driverInvoice?: null;
    consigneeInvoice?: null;
    consignerInvoice?: null;
    invoiceNumber?: null;
    invoiceVerified: boolean;
    invoiceGenerated: boolean;
    invoiceUploaded: boolean;
    offlineInvoicePrinted: boolean;
    podUrl?: null;
    podArrivedUrl?: null;
    podReceiptUrl?: null;
    podAdditional1Url?: null;
    podAdditional2Url?: null;
    podUploadedBy?: null;
    isPodUploaded: boolean;
    cancelRemarks?: null;
    CanceledBy?: null;
    shipperAgentCode: string;
    carrierAgentCode?: null;
    paymentForType?: null;
    advancePaymentForTypeRemark?: null;
    balancePaymentForTypeRemark?: null;
    billCopy?: null;
    weighingSlip?: null;
    track?: (null)[] | null;
    accountNumber?: null;
    beneficiaryName?: null;
    ifscCode?: null;
    panNumber?: null;
    accountName?: null;
    saveDetentionDeduction: boolean;
    isSamunnatiPayment: boolean;
    _id: string;
    orderId: number;
    __v: number;
    carrier_quotations?: (null)[] | null;
    createdAt: string;
    createdBy?: null;
    dispatchDate: string;
    foPayments?: (null)[] | null;
    ordertrack?: (null)[] | null;
    payments?: (PaymentsEntity)[] | null;
    remarkNotes?: (null)[] | null;
    shipperId: string;
    updatedAt: string;
}