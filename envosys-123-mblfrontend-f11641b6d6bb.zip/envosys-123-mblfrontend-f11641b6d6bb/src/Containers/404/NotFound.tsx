import { Result } from 'antd'
import AppButton from "@Components/AppButton"
import { useNavigate } from 'react-router-dom'

function NotFound() {
    const navigate = useNavigate()
    return (
        <Result
            status="404"
            title="404"
            subTitle="Sorry, the page you visited does not exist."
            extra={
                <AppButton type="primary" onClick={() => navigate(-1)}>
                    Go Back
                </AppButton>
            }
        />
    )
}

export default NotFound