import { Col, Row, Form, Flex, Typography, Button } from "antd";
import "./Login.css";
// import AppTypography from "@Components/AppTypography";
import FloatInput from "@Components/FloatInput/floatInput";
import { useState } from "react";
import { LoginImg, LogoThumbnail } from "@Assets/index";
import { useNavigate } from 'react-router-dom'

import { LOG_IN } from "@Api/Api";
// import useVerifyOtp from "@Hooks/ApiData/useVerifyOtp";

function Login() {
    const [form] = Form.useForm();
    const [userName, setUserName] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate()

    const handleLogin = async () => {
        // call login api
        let body = {
            userId: userName,
            password: password
        }
        navigate("/dashboard")
        let result = await LOG_IN(body)
        // set token in localstorage here
        // localStorage.setItem("token", result)
        console.log(result)
    };
    return (
        <>
            <img src={LogoThumbnail} alt="Logo" className="logo" />
            <Row>
                <Col span={16} className="backgroundSignIn">
                    <Flex vertical align="center" justify="center" className="h-full">
                        <Typography.Title level={2}>
                            Hi, Welcome back
                        </Typography.Title>
                        <img src={LoginImg} alt="" className="login-img" />
                    </Flex>

                </Col>
                <Col span={8}>

                    <Flex vertical justify="center" align="center" className="h-full text-left">
                        <div className="w-5/6">
                            <Typography.Title level={3} className="m-0">
                                Sign in to Envosys
                            </Typography.Title>
                            <Typography.Text className="secondary-text my-9 block">
                                New user? <Typography.Link className="text-theme font-semibold">Create an account</Typography.Link>
                            </Typography.Text>

                            <Form form={form} onFinish={handleLogin}>
                                <Form.Item name="UserName" className="mb-3">
                                    <FloatInput
                                        type="text"
                                        label="User Name"
                                        value={""}
                                        name="user Name"
                                        onChange={(e: any) => setUserName(e.target.value)}
                                    />
                                </Form.Item>
                                <Form.Item name="Password">
                                    <FloatInput
                                        label="Password"
                                        name="Password"
                                        onChange={(e: any) => setPassword(e.target.value)}
                                        type="password"
                                        value={""}
                                    />
                                </Form.Item>

                                <Typography.Link style={{ textDecoration: "underline" }} className="my-6 block text-right text-secondary">
                                    Forgot Password?
                                </Typography.Link>

                                <Flex justify="center" className="w-full">
                                    <Button
                                        className="w-full"
                                        htmlType="submit"
                                        type="primary"
                                        style={{ height: "45px" }}
                                    >
                                        Login
                                    </Button>
                                </Flex>
                            </Form>
                        </div>
                    </Flex>
                </Col>
            </Row>
        </>
    );
}

export default Login;
