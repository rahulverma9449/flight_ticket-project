import { Col, Form, Row, Select } from "antd";

import style from "./signin.module.css";
import AppTypography from "@Components/AppTypography";
import AppButton from "@Components/AppButton";
import AppInput from "@Components/AppInput";

const { Item } = Form;

function SignUp() {
    // const [signUpForm] = Form.useForm();
    // const destination = useWatch("locality", signUpForm) || "";

    //   const onFinish = (data: any) => {
    //     let val = { ...data };
    //     val.mobile_number = userData?.mobile_number;
    //     sendRegisterRequest(val);
    //   };
    return (
        <Row className={style.backgroundSignIn} justify={"center"} align={"middle"}>
            <Col className={style.signInModal}>
                <Row gutter={[24, 36]}>
                    <Col span={24} className={style.textCenter}>
                        {/* <img src={AgriLogo} alt="" /> */}
                    </Col>
                    <Col span={24} className={style.textCenter}>
                        <AppTypography fontsize={16} type="Paragraph" color={"#555"}>
                            Create your account first to make
                            <br />
                            grains supply efficient
                        </AppTypography>
                    </Col>

                    <Col span={24}>
                        {/* <Form form={signUpForm} name="basic" onFinish={onFinish}> */}
                        <Item
                            name="fullname"
                            rules={[
                                {
                                    required: true,
                                    message: "Name is required",
                                },
                            ]}
                        >
                            <AppInput placeholder="Enter full name" />
                        </Item>
                        <Item
                            name="business_category"
                            rules={[
                                {
                                    required: true,
                                    message: "Category is required",
                                },
                            ]}
                        >
                            <Select
                                placeholder="Business Category"
                            //   options={BusinessCategories}
                            />
                        </Item>
                        <Item name="email">
                            <AppInput placeholder="Email" />
                        </Item>
                        <Item
                            name="locality"
                            rules={[
                                {
                                    required: true,
                                    message: "locality is required",
                                },
                            ]}
                        >
                            {/* <PlaceAutocomplete
                  value={destination}
                  handleSelect={(address: any) =>
                    signUpForm.setFieldValue("locality", address)
                  }
                  handleChange={(address: any) =>
                    signUpForm.setFieldValue("locality", address)
                  }
                  // handleLatLng={(latLng: { lat: any; lng: any }) => {
                  //   setDestinationLatLng((prevState: any) => ({
                  //     ...prevState,
                  //     latitude: latLng.lat,
                  //     longitude: latLng.lng,
                  //   }))
                  // }}
                  className="border rounded-md ant-input w-full border-[#d9d9d9] border-solid py-2 focus-visible:outline-0 ps-2 box-border placeholder:text-gray-300"
                  name="locality"
                  placeholder="Locality"
                /> */}
                        </Item>
                        {/* <Item name="code">
                <AppInput placeholder="Referral / Onboarding Code" />
              </Item> */}

                        <Item>
                            <Row justify={"center"}>
                                <Col>
                                    <AppButton
                                        fontSize="20px"
                                        fontWeight={600}
                                        className={style.signinbutton}
                                        htmlType="submit"
                                        type="primary"
                                    >
                                        Signup
                                    </AppButton>
                                </Col>
                            </Row>
                        </Item>
                        {/* </Form> */}
                    </Col>
                </Row>
            </Col>
        </Row>
    );
}

export default SignUp;
