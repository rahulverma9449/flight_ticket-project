import { Flex } from "antd";
import "./Dashboard.css";

function Dashboard() {

    return (
        <Flex className="w-full h-96" align="center" justify="center">
            <h1 className="text-2xl font-bold">Coming Soon !</h1>
        </Flex>
    );
}

export default Dashboard;