import { useState } from 'react';
import { Col, Row, Collapse, Flex, Tabs, Space, Dropdown, MenuProps, Button, Typography, ConfigProvider } from 'antd';
import { DownOutlined, ToolOutlined, CloseOutlined, RightOutlined, PlusOutlined } from '@ant-design/icons';
import HBLCard from "@Components/HBLCard";
import AutoComplete from "@Components/AutoComplete";
import FloatInput from "@Components/FloatInput/floatInput";
import DatePickerInput from "@Components/DatePicker";
import AppTypography from '@Components/AppTypography';
import AppButton from "@Components/AppButton";
import ContainerTable from "./component/containerTable";
import UploadFile from "./component/uploadFile";

import './mblForm.css'
import { AuditTab, BasicTab, ContainerItemTab, DocCenterTab, NominationTab, OthersTab, PartyTab } from '@Assets/index';
import AuditTimeline from './component/AuditTimeline';
// import GenericDropdown from '@Components/GenericDropdown';

const { TabPane } = Tabs;
function MblForm() {
    const options = [
        { value: 'Burns Bay Road', key: "test1" },
        { value: 'Downing Street', key: "test1" },
        { value: 'Wall Street', key: "test1" },
    ];

    const yesNo = [
        { value: 'YES', key: "1" },
        { value: 'NO', key: "2" },
    ];

    const testOptions = [
        { value: 'OptionOne', key: "1" },
        { value: 'OptionTwo', key: "2" },
        { value: 'OptionThree', key: "3" },
    ];

    const [hblFormToggle, setHblFormToggle] = useState(true)
    const [isOpen, setIsOpen] = useState(true);

    const [hblData] = useState([
        { hblNo: "abcd12345678" },
        { hblNo: "abcd12345678" },
        { hblNo: "abcd12345678" },
    ]);

    const [mblFormData, setMblFormData] = useState({
        masterBlNumber: "",
        masterBlDate: "",
        agentName: "",
        line: "",
        vessel: "",
        voyage: "",
        placeOfReceipt: "",
        pol: "",
        pod: "",
        fpd: "",
        shipmentType: "",
        coloaderName: "",
        vesselArrivalDate: "",
        agentRefNo: "",
        destuffingPoint: "",
        remarks: "",
        etd: "",
        coloadMblno: "",
    });

    const [hblFormData, setHblFormData] = useState({
        masterBlNumber: "",
        jobNo: "",
        houseBlNumber: "",
        blDate: "",
        forwardedBlNo: "",
        forwardedBlDate: "",
        serviceBlNo: "",
        serviceBlDate: "",
        endBl: "",
        blNo: "",
        smtp: "",
        IcdName: "",
        nomination: "",
        marketingPersion: "",
        customerService: "",
        cfsName: "",
    });

    const items: MenuProps['items'] = [
        {
            label: 'Settings',
            key: '1',
        },
        {
            label: 'Profile',
            key: '2',
        },
        {
            label: "",
            key: '3',
        },
    ];

    const [containerItems] = useState([
        {
            key: '1', ContainerNo: 123456789, SizeType: 32, SealNo: 321, NoOfPackage: 231, PackageType: "Demo",
            GrWt: 12.0, Volume: 213, Haz: true, AgentSealNo: 12
        },
        {
            key: '2', ContainerNo: 123456789, SizeType: 32, SealNo: 321, NoOfPackage: 231, PackageType: "Demo",
            GrWt: 12.0, Volume: 213, Haz: false, AgentSealNo: 12
        },
    ]);


    const handleSelectValue = (value: any, type: any) => {
        try {
            setMblFormData({ ...mblFormData, [type]: value });
        } catch (error) {
            console.error("Error updating mblFormData:", error);
        }
    }

    const handleHblSelectValue = (value: any, type: any) => {
        try {
            setHblFormData({ ...hblFormData, [type]: value });
        } catch (error) {
            console.error("Error updating hblFormData:", error);
        }
    }

    const handleChange = (value: any) => {
        if (value.length <= 0) {
            setMblFormData(value)
        }
    }

    const toggleCollapse = () => {
        setIsOpen(!isOpen);
    };

    const toggleCloseHandler = () => {
        setIsOpen(false);
    };

    const hblFormCloseHandler = () => {
        // Stop event propagation to prevent Collapse from toggling
        // e.stopPropagation();
        setHblFormToggle(false);

    };

    const dataSource = [
        {
            key: 1,
            docName: "File1",
            docType: "Pdf",
            ShowToCustomer: "Yes",
            uploadedBy: "Demo",
            uploadedDate: "21/05/2024",
            internalType: "ABC"
        },
        {
            key: 2,
            docName: "File2",
            docType: "Pdf",
            ShowToCustomer: "No",
            uploadedBy: "Demo2",
            uploadedDate: "21/05/2024",
            internalType: "Bcd"
        },
    ];

    // const handleSelect = () => {

    // }

    return (
        <>
            <Flex justify='space-between' className='mb-3'>
                <Flex align='center'>
                    {
                        hblData.map((data) => {
                            return (
                                <>
                                    <HBLCard hblNo={data.hblNo} cardColor='bg-blue-400' cardActive={true} />
                                </>
                            )
                        })
                    }
                </Flex>

                <Button type='primary' icon={<PlusOutlined />} onClick={toggleCloseHandler}>Add New HB/L</Button>
            </Flex>

            <Space direction='vertical' size={'middle'} className='w-full'>
                {/* MBL Card */}
                <Collapse
                    activeKey={isOpen ? '1' : undefined}
                    className='collapse-card mbl-card'
                    size='small'
                    onChange={toggleCollapse}
                    expandIcon={({ isActive }) => <RightOutlined style={{ fontSize: "16px", color: "white" }} rotate={isActive ? 90 : 0} />}
                    expandIconPosition="end"
                    items={[
                        {
                            key: '1',
                            label: (
                                <Flex justify="space-between" align='center'>
                                    <AppTypography type='Title' color='white'>MBL Details</AppTypography>
                                    <Dropdown menu={{ items }}>
                                        <AppButton>
                                            <Space>
                                                <ToolOutlined className="formIcon" />
                                                Tools
                                                <DownOutlined className="formIcon" />
                                            </Space>
                                        </AppButton>
                                    </Dropdown>
                                </Flex>
                            ),
                            children: (
                                <Tabs defaultActiveKey="1" >
                                    <TabPane tab={
                                        <Space>
                                            <img src={BasicTab} alt='' />
                                            Basic
                                        </Space>
                                    } key="1">
                                        <Row gutter={[10, 10]}>
                                            <Col span={6}>
                                                <FloatInput
                                                    label="Master BL No"
                                                    name="Master BL No"
                                                    onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                    type="text"
                                                    value={mblFormData.masterBlNumber}
                                                />
                                            </Col>
                                            <Col span={6}>
                                                <DatePickerInput
                                                    label="Master BL Date"
                                                    // value={mblFormData.vesselArrivalDate}
                                                    // type="vesselArrivalDate"
                                                    handleSelectValue={handleSelectValue}
                                                // placeholder="Select Date"
                                                />
                                            </Col>
                                            <Col span={6}>
                                                <AutoComplete
                                                    label="Agent Name"
                                                    type="agentName"
                                                    value={mblFormData.agentName}
                                                    placeholder="Agent Name"
                                                    required={true}
                                                    options={options}
                                                    handleSelectValue={handleSelectValue}
                                                    handleChange={handleChange}
                                                />
                                            </Col>
                                            <Col span={6}>
                                                <AutoComplete
                                                    label="Line"
                                                    type="line"
                                                    value={mblFormData.line}
                                                    placeholder="Line"
                                                    required={true}
                                                    options={options}
                                                    handleSelectValue={handleSelectValue}
                                                    handleChange={handleChange}
                                                />
                                            </Col>
                                            <Col span={6}>
                                                <AutoComplete
                                                    label="Vessel"
                                                    value={mblFormData.vessel}
                                                    type="vessel"
                                                    placeholder="Vessel"
                                                    required={true}
                                                    options={options}
                                                    handleSelectValue={handleSelectValue}
                                                    handleChange={handleChange}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <FloatInput
                                                    label="Voyage"
                                                    // placeholder="Email here please"
                                                    name="Voyage"
                                                    onChange={(e: any) => { setMblFormData({ ...mblFormData, 'voyage': e.target.value }) }}
                                                    type="text"
                                                    value={mblFormData.voyage}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <AutoComplete
                                                    label="Place Of Receipt"
                                                    value={mblFormData.placeOfReceipt}
                                                    type="placeOfReceipt"
                                                    placeholder="Place Of Receipt"
                                                    required={true}
                                                    options={options}
                                                    handleSelectValue={handleSelectValue}
                                                    handleChange={handleChange}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <AutoComplete
                                                    label="Pol"
                                                    value={mblFormData.pol}
                                                    type="pol"
                                                    placeholder="Pol"
                                                    required={true}
                                                    options={options}
                                                    handleSelectValue={handleSelectValue}
                                                    handleChange={handleChange}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <AutoComplete
                                                    label="Pod"
                                                    value={mblFormData.pod}
                                                    type="pod"
                                                    placeholder="Pod"
                                                    required={true}
                                                    options={options}
                                                    handleSelectValue={handleSelectValue}
                                                    handleChange={handleChange}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <AutoComplete
                                                    label="FPD"
                                                    value={mblFormData.pol}
                                                    type="fpd"
                                                    placeholder="FPD"
                                                    required={true}
                                                    options={options}
                                                    handleSelectValue={handleSelectValue}
                                                    handleChange={handleChange}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <AutoComplete
                                                    label="Shipment Type"
                                                    value={mblFormData.shipmentType}
                                                    type="shipmentType"
                                                    placeholder="Shipment Type"
                                                    required={true}
                                                    options={options}
                                                    handleSelectValue={handleSelectValue}
                                                    handleChange={handleChange}
                                                />
                                            </Col>
                                            <Col span={6}>
                                                <FloatInput
                                                    label="Coloader Name"
                                                    // placeholder="Email here please"
                                                    name="Coloader Name"
                                                    onChange={(e: any) => { setMblFormData({ ...mblFormData, 'coloaderName': e.target.value }) }}
                                                    type="text"
                                                    value={mblFormData.coloaderName}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <DatePickerInput
                                                    label="Vessel ArrivalDate"
                                                    // value={mblFormData.vesselArrivalDate}
                                                    type="vesselArrivalDate"
                                                    handleSelectValue={handleSelectValue}
                                                // placeholder="Select Date"
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <FloatInput
                                                    label="Agent Ref No"
                                                    // placeholder="Email here please"
                                                    name="Agent Ref No"
                                                    onChange={(e: any) => { setMblFormData({ ...mblFormData, 'agentRefNo': e.target.value }) }}
                                                    type="text"
                                                    value={mblFormData.agentRefNo}
                                                />
                                            </Col>


                                            <Col span={6}>
                                                <FloatInput
                                                    label="Destuffing Point"
                                                    // placeholder="Email here please"
                                                    name="Destuffing Point"
                                                    onChange={(e: any) => { setMblFormData({ ...mblFormData, 'destuffingPoint': e.target.value }) }}
                                                    type="text"
                                                    value={mblFormData.destuffingPoint}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <FloatInput
                                                    label="Remarks"
                                                    isTextArea={true}
                                                    name="Remarks"
                                                    onChange={(e: any) => { setMblFormData({ ...mblFormData, 'remarks': e.target.value }) }}
                                                    type="text"
                                                    value={mblFormData.remarks}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <FloatInput
                                                    label="ETD"
                                                    // placeholder="Email here please"
                                                    name="ETD"
                                                    onChange={(e: any) => { setMblFormData({ ...mblFormData, 'etd': e.target.value }) }}
                                                    type="text"
                                                    value={mblFormData.etd}
                                                />
                                            </Col>

                                            <Col span={6}>
                                                <FloatInput
                                                    label="Coload Mblno"
                                                    // placeholder="Email here please"
                                                    name="Coload Mblno"
                                                    onChange={(e: any) => { setMblFormData({ ...mblFormData, 'coloadMblno': e.target.value }) }} type="text"
                                                    value={mblFormData.coloadMblno}
                                                />
                                            </Col>
                                        </Row>
                                    </TabPane>

                                    <TabPane tab={
                                        <Space>
                                            <img src={ContainerItemTab} alt='' />
                                            Container & Item
                                        </Space>
                                    } key="2">
                                        <Row gutter={[20, 20]}>
                                            {/* <Col span={24}>
                                                <Button type='primary' icon={<CopyOutlined />} >
                                                    Copy
                                                </Button>
                                            </Col> */}
                                            <Col span={24}>
                                                <ContainerTable checkboxEnable={false}
                                                    containerItems={containerItems}
                                                    actionRow={true}
                                                />
                                            </Col>
                                        </Row>
                                    </TabPane>

                                    <TabPane tab={
                                        <Space>
                                            <img src={DocCenterTab} alt='' />
                                            Doc Center
                                        </Space>
                                    } key="3">
                                        <UploadFile checkBox={false} data={dataSource} />
                                    </TabPane>

                                    <TabPane tab={
                                        <Space>
                                            <img src={AuditTab} alt='' />
                                            Audit
                                        </Space>
                                    } key="4">
                                        <AuditTimeline />
                                    </TabPane>
                                </Tabs>
                            )
                        }
                    ]}
                />

                {/* HBL Card*/}
                {hblFormToggle &&
                    <Collapse
                        className='bg-yellow-500'
                        size='small'
                        activeKey={['1']}
                        items={[
                            {
                                key: '1',
                                showArrow: false,
                                label: (
                                    <Flex justify="space-between" align='center'>
                                        <AppTypography type='Title' color='white'>HBL Details</AppTypography>
                                        <Space>
                                            <Dropdown menu={{ items }}>
                                                <AppButton>
                                                    <Space>
                                                        <ToolOutlined className="formIcon" />
                                                        Tools
                                                        <DownOutlined className="formIcon" />
                                                    </Space>
                                                </AppButton>
                                            </Dropdown>
                                            <CloseOutlined className="formIconWhite" onClick={hblFormCloseHandler} />
                                        </Space>
                                    </Flex>
                                ),
                                children: (
                                    <Tabs defaultActiveKey="1" >
                                        <TabPane tab={
                                            <Space>
                                                <img src={BasicTab} alt='' />
                                                Basic
                                            </Space>
                                        } key="1">
                                            <Row gutter={[10, 10]}>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Master BL No"
                                                        name="Master BL No"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'masterBlNumber': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.masterBlNumber}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Job Number"
                                                        name="Job No"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'jobNo': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.jobNo}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <FloatInput
                                                        label="House Bl NUmber"
                                                        name="Job No"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'houseBlNumber': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.houseBlNumber}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <DatePickerInput
                                                        label="BL Date"
                                                        // value={mblFormData.vesselArrivalDate}
                                                        type="BL Date"
                                                        handleSelectValue={handleHblSelectValue}
                                                    // placeholder="Select Date"
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Forwarded Bl NUmber"
                                                        name="Job No"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'forwardedBlNo': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.forwardedBlNo}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <DatePickerInput
                                                        label="Forwarded BL Date"
                                                        // value={mblFormData.vesselArrivalDate}
                                                        type="Forwarded BL Date"
                                                        handleSelectValue={handleHblSelectValue}
                                                    // placeholder="Select Date"
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Service Bl NUmber"
                                                        name="Job No"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'serviceBlNo': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.serviceBlNo}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <DatePickerInput
                                                        label="Service BL Date"
                                                        // value={mblFormData.vesselArrivalDate}
                                                        type="Service BL Date"
                                                        handleSelectValue={handleHblSelectValue}
                                                    // placeholder="Select Date"
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="End BL"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="End BL"
                                                        required={true}
                                                        options={yesNo}
                                                        handleSelectValue={handleHblSelectValue}
                                                        handleChange={handleChange}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <FloatInput
                                                        label="BL No"
                                                        name="Bl No"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'blNo': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.blNo}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="SMTP"
                                                        value={hblFormData.smtp}
                                                        type="smtp"
                                                        placeholder="SMTP"
                                                        required={true}
                                                        options={yesNo}
                                                        handleSelectValue={handleHblSelectValue}
                                                        handleChange={handleChange}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="ICD Name"
                                                        name="ICD Name"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'IcdName': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.IcdName}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="Nomination"
                                                        value={hblFormData.nomination}
                                                        type="nomination"
                                                        placeholder="Nomination"
                                                        required={true}
                                                        options={yesNo}
                                                        handleSelectValue={handleHblSelectValue}
                                                        handleChange={handleChange}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Marketing Person"
                                                        name="Marketing Person"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'marketingPersion': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.marketingPersion}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Customer Service"
                                                        name="Customer Service"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'customerService': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.customerService}
                                                    />
                                                </Col> <Col span={6}>
                                                    <FloatInput
                                                        label="CFS Name"
                                                        name="CFS Name"
                                                        onChange={(e: any) => { setHblFormData({ ...hblFormData, 'cfsName': e.target.value }) }}
                                                        type="text"
                                                        value={hblFormData.marketingPersion}
                                                    />
                                                </Col>
                                            </Row>
                                        </TabPane>

                                        <TabPane tab={
                                            <Space>
                                                <img src={PartyTab} alt='' />
                                                Party Details
                                            </Space>
                                        } key="2">

                                            <Space className='gap-5 w-full' direction='vertical'>
                                                {/* Shipper details */}
                                                <Space className='w-full border-b pb-6' direction='vertical'>
                                                    <Row>
                                                        <Typography.Title level={4} className='text-theme'>Shipper Details</Typography.Title>
                                                    </Row>
                                                    <Row gutter={[10, 10]}>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Name"
                                                                name="Name"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Address"
                                                                name="Address"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Telephone"
                                                                name="Master BL No"
                                                                onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                                value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Fax"
                                                                name="Fax"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Email"
                                                                name="Email"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                    </Row>
                                                </Space>

                                                {/* Consignee details */}
                                                <Space className='w-full border-b pb-6' direction='vertical'>
                                                    <Row>
                                                        <Typography.Title level={4} className='text-theme'>Consignee Details</Typography.Title>
                                                    </Row>
                                                    <Row gutter={[10, 10]}>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Name"
                                                                name="Name"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Address"
                                                                name="Address"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Telephone"
                                                                name="Master BL No"
                                                                onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                                value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Fax"
                                                                name="Fax"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Email"
                                                                name="Email"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                    </Row>
                                                </Space>

                                                {/* Notify party 1 */}
                                                <Space className='w-full border-b pb-6' direction='vertical'>
                                                    <Row>
                                                        <Typography.Title level={4} className='text-theme'>Notify party 1</Typography.Title>
                                                    </Row>
                                                    <Row gutter={[10, 10]}>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Name"
                                                                name="Name"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Address"
                                                                name="Address"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Telephone"
                                                                name="Master BL No"
                                                                onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                                value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Fax"
                                                                name="Fax"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Email"
                                                                name="Email"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                    </Row>
                                                </Space>

                                                {/* Notify party 2 */}
                                                <Space className='w-full pb-6' direction='vertical'>
                                                    <Row>
                                                        <Typography.Title level={4} className='text-theme'>Notify party 2</Typography.Title>
                                                    </Row>
                                                    <Row gutter={[10, 10]}>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Name"
                                                                name="Name"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Address"
                                                                name="Address"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Telephone"
                                                                name="Master BL No"
                                                                onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                                value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Fax"
                                                                name="Fax"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                        <Col span={6}>
                                                            <FloatInput
                                                                label="Email"
                                                                name="Email"
                                                                // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                                type="text"
                                                            // value={mblFormData.masterBlNumber}
                                                            />
                                                        </Col>
                                                    </Row>
                                                </Space>
                                            </Space>
                                        </TabPane>

                                        <TabPane tab={
                                            <Space>
                                                <img src={NominationTab} alt='' />
                                                Nomination
                                            </Space>
                                        } key="3">
                                            <Row gutter={[10, 10]}>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Invoice Number"
                                                        name="Invoice Number"
                                                        // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                        type="text"
                                                    // value={mblFormData.masterBlNumber}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="P.O.No"
                                                        name="P.O.No"
                                                        // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                        type="text"
                                                    // value={mblFormData.masterBlNumber}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Ref1"
                                                        name="Ref1"
                                                        // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                        type="text"
                                                    // value={mblFormData.masterBlNumber}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Ref2"
                                                        name="Ref2"
                                                        // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                        type="text"
                                                    // value={mblFormData.masterBlNumber}
                                                    />
                                                </Col>
                                            </Row>
                                        </TabPane>

                                        <TabPane tab={
                                            <Space>
                                                <img src={OthersTab} alt='' />
                                                Others
                                            </Space>
                                        } key="4">
                                            <Row gutter={[10, 10]}>
                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="Freight"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="Freight"
                                                        // required={true}
                                                        options={testOptions}
                                                        handleSelectValue={handleHblSelectValue}
                                                        handleChange={handleChange}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Freight Amount"
                                                        name="Freight Amount"
                                                        // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                        type="text"
                                                    // value={mblFormData.masterBlNumber}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="Cargo Type"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="Cargo Type"
                                                        required={true}
                                                        options={testOptions}
                                                    // handleSelectValue={handleHblSelectValue}
                                                    // handleChange={handleChange}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="Item Type"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="Item Type"
                                                        required={true}
                                                        options={testOptions}
                                                    // handleSelectValue={handleHblSelectValue}
                                                    // handleChange={handleChange}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="Cargo Movement"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="Cargo Movement"
                                                        required={true}
                                                        options={testOptions}
                                                    // handleSelectValue={handleHblSelectValue}
                                                    // handleChange={handleChange}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="Haz"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="Haz"
                                                        required={true}
                                                        options={testOptions}
                                                    // handleSelectValue={handleHblSelectValue}
                                                    // handleChange={handleChange}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Uno Code"
                                                        name="Uno Code"
                                                        // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                        type="text"
                                                    // value={mblFormData.masterBlNumber}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="BL Status"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="BL Status"
                                                        required={true}
                                                        options={testOptions}
                                                    // handleSelectValue={handleHblSelectValue}
                                                    // handleChange={handleChange}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <FloatInput
                                                        label="Remarks"
                                                        name="Remarks"
                                                        // onChange={(e: any) => { setMblFormData({ ...mblFormData, 'masterBlNumber': e.target.value }) }}
                                                        type="text"
                                                    // value={mblFormData.masterBlNumber}
                                                    />
                                                </Col>

                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="RO Number"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="RO Number"
                                                        required={true}
                                                        options={testOptions}
                                                        handleSelectValue={handleHblSelectValue}
                                                        handleChange={handleChange}
                                                    />
                                                </Col>
                                                <Col span={6}>
                                                    <AutoComplete
                                                        label="Invoice to be made"
                                                        value={hblFormData.endBl}
                                                        type="endBl"
                                                        placeholder="Invoice to be made"
                                                        required={true}
                                                        options={testOptions}
                                                        handleSelectValue={handleHblSelectValue}
                                                        handleChange={handleChange}
                                                    />
                                                </Col>
                                            </Row>
                                        </TabPane>

                                        <TabPane tab={
                                            <Space>
                                                <img src={ContainerItemTab} alt='' />
                                                Container & Item
                                            </Space>
                                        } key="5">
                                            <ContainerTable
                                                checkboxEnable={false}
                                                containerItems={containerItems} 
                                                actionRow={false}
                                                disable={true}
                                                />
                                        </TabPane>

                                        <TabPane tab={
                                            <Space>
                                                <img src={DocCenterTab} alt='' />
                                                Doc Center
                                            </Space>
                                        }
                                            key="6">
                                            <UploadFile deleButton={false} checkBox={false} data={dataSource} />
                                        </TabPane>

                                        <TabPane tab={
                                            <Space>
                                                <img src={AuditTab} alt='' />
                                                Audit
                                            </Space>
                                        } key="7">
                                            <AuditTimeline />
                                        </TabPane>
                                    </Tabs>
                                )
                            }
                        ]}
                    />
                }

            </Space>

            <Flex className='floating-btns' gap={15}>
                <ConfigProvider
                    theme={{
                        components: {
                            Button: {
                                colorPrimary: "#36B37E",
                                colorPrimaryActive: "#36B37E",
                                colorPrimaryHover: "#36B37E",
                            },
                        },
                    }}
                >
                    <Button type="primary" className='shadow-md shadow-green-300'>
                        Save
                    </Button>
                </ConfigProvider>
                <ConfigProvider
                    theme={{
                        components: {
                            Button: {
                                colorPrimary: "#FF5630",
                                colorPrimaryActive: "#f57052",
                                colorPrimaryHover: "#f57052",
                            },
                        },
                    }}
                >
                    <Button type="primary" className='shadow shadow-red-400'>
                        Cancel
                    </Button>
                </ConfigProvider>
            </Flex>
        </>
    );
}

export default MblForm;