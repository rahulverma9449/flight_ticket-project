import React from 'react';
import { CaretRightOutlined } from '@ant-design/icons';
import { Collapse, ConfigProvider, Timeline } from 'antd';

const AuditTimeline: React.FC = () => {
  let timelineItems = [];

  let timelineData = [
    {
      color: "#303981",
      label: 'Heading 1',
      children: 'Create a services',
    },
    {
      color: "#26A59A",
      label: 'Heading 2',
      children: 'Solve initial network problems',
    },
    {
      color: "#61A5FA",
      label: "Heading 3",
      children: 'Technical testing',
    },
    {
      color: "#E8615B",
      label: 'Heading 4',
      children: 'Network problems being solved',
    },
  ]

  for (let i = 0; i < timelineData.length; i++) {
    let obj = {
      color: timelineData[i].color,
      label: '2015-09-01 09:12:11',
      children: (
        <ConfigProvider
          theme={{
            components: {
              Collapse: {
                headerBg: timelineData[i].color,
                contentBg: "white",
              },
            },
          }}
        >
          <Collapse
            className='audit-card'
            expandIcon={({ isActive }) => <CaretRightOutlined rotate={isActive ? 90 : 0} />}
            expandIconPosition="end"
            items={[
              {
                label: timelineData[i].label,
                children: <p>{timelineData[i].children}</p>,
              }
            ]}
          />
        </ConfigProvider>

      ),
    }
    timelineItems.push(obj)

  }
  return (
    <>
      <Timeline
        className='mt-2'
        mode="left"
        items={timelineItems}
      />
    </>

  );
};

export default AuditTimeline;