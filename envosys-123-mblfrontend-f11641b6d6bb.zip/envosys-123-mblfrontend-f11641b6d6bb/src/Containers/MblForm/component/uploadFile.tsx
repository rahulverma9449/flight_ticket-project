import { useState } from 'react';
import { CloudDownloadOutlined } from '@ant-design/icons';
import { UploadProps, message, Upload, Modal, Form, Button, Row, Col, Typography, Table, Flex, Select, Switch } from 'antd';
import { UploadImg } from '@Assets/index';

const { Dragger } = Upload;

const UploadFile = (props: any) => {

    const [modalVisible, setModalVisible] = useState(false);
    const [form] = Form.useForm();
    const [fileToUpload, setFileToUpload] = useState<any>(null);
    const columns = [
        {
            title: 'Doc Name',
            dataIndex: 'docName',
            key: 'docName',
        },
        {
            title: 'Doc Type',
            dataIndex: 'docType',
            key: 'docType',
        },
        {
            title: 'Show To Customer',
            dataIndex: 'ShowToCustomer',
            key: 'ShowToCustomer',
        },
        {
            title: 'Uploaded By',
            dataIndex: 'uploadedBy',
            key: 'uploadedBy',
        },
        {
            title: 'Uploaded Date',
            dataIndex: 'uploadedDate',
            key: 'uploadedDate',
        },
        {
            title: 'Action',
            key: 'action',
            // width: 110,
            // fixed: 'right',
            // render: (record: any) => (
            render: () => (
                <Flex gap={10}>
                    <Button type='primary' className='px-2' icon={<CloudDownloadOutlined />}>
                        Download
                    </Button>
                </Flex>
            ),
        },
    ];

    const [uploadProps] = useState<UploadProps>({
        name: 'file',
        multiple: true,
        action: 'https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload',
        onChange(info) {
            const { status } = info.file;
            if (status !== 'uploading') {
                console.log(info.file, info.fileList);
            }
            if (status === 'done') {
                message.success(`${info.file.name} file uploaded successfully.`);
            } else if (status === 'error') {
                message.error(`${info.file.name} file upload failed.`);
            }
        },
        onDrop(e) {
            console.log('Dropped files', e.dataTransfer.files);
        },
        beforeUpload: (file) => {
            setFileToUpload(file);
            setModalVisible(true);
            return false; // Prevent upload
        },
    });

    const handleOk = () => {
        form.validateFields().then(values => {
            console.log('Form Values:', values);
            setModalVisible(false);
            // Trigger the upload manually after closing the modal
            const formData = new FormData();
            formData.append('file', fileToUpload);
            for (const key in values) {
                formData.append(key, values[key]);
            }
            fetch('https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload', {
                method: 'POST',
                body: formData,
            })
                .then(response => response.json())
                .then(data => {
                    console.log('Success:', data);
                    message.success(`${fileToUpload.name} file uploaded successfully.`);
                })
                .catch(error => {
                    console.error('Error:', error);
                    message.error(`${fileToUpload.name} file upload failed.`);
                });
        });
    };

    const handleCancel = () => {
        setModalVisible(false);
        setFileToUpload(null);
    };

    const rowSelection = {
        onChange: (selectedRowKeys: React.Key[], selectedRows: any) => {
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
        },
        getCheckboxProps: (record: any) => ({
            disabled: record.name === 'Disabled User', // Column configuration not to be checked
            name: record.name,
        }),
    };

    return (
        <Row className='w-full' gutter={20}>
            <Col span={6}>
                <Flex vertical className='h-full' gap={5}>
                    <Typography.Title level={4}>
                        Select Files
                    </Typography.Title>
                    <Dragger {...uploadProps} className='flex-grow' fileList={[]}>
                        <p className="ant-upload-drag-icon">
                            {/* <InboxOutlined /> */}
                            <img src={UploadImg} alt="Upload" className='mx-auto' />
                        </p>
                        <Typography className="ant-upload-hint">
                            Drop file here or click to <span className='underline text-theme'>browse</span> through your machine
                        </Typography>
                    </Dragger>
                </Flex>

                <Modal
                    title="Select Type"
                    visible={modalVisible}
                    onOk={handleOk}
                    onCancel={handleCancel}
                    footer={[
                        <Button key="back" onClick={handleCancel}>
                            Cancel
                        </Button>,
                        <Button key="submit" type="primary" onClick={handleOk}>
                            Submit
                        </Button>,
                    ]}
                >
                    <Form form={form} layout="vertical">
                        <Form.Item
                            name="Doc Type"
                            label="Doc Type"
                            rules={[{ required: true, message: 'Please select doc type' }]}
                        >
                            <Select
                                defaultValue="1"
                                // onChange={handleChange}
                                options={[
                                    { value: '1', label: 'type1' },
                                    { value: '2', label: 'type2' },
                                ]}
                            />
                        </Form.Item>
                        <Form.Item
                            name="Show to Customer"
                            label="Show to Customer"
                            rules={[{ required: true, message: 'Please select Show to Customer' }]}
                        >
                            <Switch disabled={props.disable || false}
                                // onChange={(e) => handleInputChange(e, record.key, 'Haz')}
                                // checked={record.Haz} 
                                checkedChildren="Yes" unCheckedChildren="No" />
                        </Form.Item>
                    </Form>
                </Modal>
            </Col>
            <Col span={18}>
                {/* <Row>
                    <Space direction='vertical' className='mb-2'>
                        <Typography.Title level={4}>
                            Document List
                        </Typography.Title>
                        {props.checkBox &&
                            <Button type='primary' icon={<CopyOutlined />} >
                                Copy
                            </Button>}

                    </Space>
                </Row> */}
                <Row className='mt-8'>
                    <Table
                        className='w-full'
                        rowSelection={props.checkBox ? {
                            type: "checkbox",
                            ...rowSelection,
                        } : undefined}
                        dataSource={props.data}
                        columns={columns} />
                </Row>
            </Col>
        </Row >

    );
};

export default UploadFile;
