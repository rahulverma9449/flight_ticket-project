import React, { useState } from 'react';
import { Table, Input, Select, Button, Switch } from 'antd';
import { MinusCircleOutlined } from '@ant-design/icons';
import type { ColumnType } from 'antd/es/table';

const { Option } = Select;

interface DataItem {
    key: string;
    Select: boolean;
    ContainerNo: number;
    SizeType: string;
    SealNo: number;
    NoOfPackage: number;
    PackageType: string;
    GrWt: number;
    Volume: number;
    Haz: boolean;
    AgentSealNo: number;
}

const ContainerTable = (props: any) => {
    const [data, setData] = useState<DataItem[]>(props.containerItems);

    const handleInputChange = (e: any, key: string, column: keyof DataItem) => {
        const newData: any = [...data];
        const index = newData.findIndex((item: { key: string; }) => item.key === key);
        if (index > -1) {
            if (column === 'Haz' || column === 'Select') {
                newData[index][column] = e;
            } 
            else {
                newData[index][column] = e.target.value;
            }
            setData(newData);
        }
    };

    const handleAddRow = () => {
        const newData = [...data];
        const newKey = (parseInt(newData[newData.length - 1].key) + 1).toString();
        newData.push({
            key: newKey,
            Select: false,
            ContainerNo: 0,
            SizeType: "",
            SealNo: 0,
            NoOfPackage: 0,
            PackageType: "",
            GrWt: 0,
            Volume: 0,
            Haz: false,
            AgentSealNo: 0,
        });
        setData(newData);
    };

    const handleRemoveRow = (key: string) => {
        const newData = data.filter(item => item.key !== key);
        setData(newData);
    };

    const columns: ColumnType<DataItem>[] = [
        {
            title: 'Container No',
            dataIndex: 'ContainerNo',
            render: (_: any, record: DataItem) => (
                <Input value={record.ContainerNo} disabled={props.disable || false}
                    onChange={(e) => handleInputChange(e, record.key, 'ContainerNo')} />
            ),
        },
        {
            title: 'Size Type',
            dataIndex: 'SizeType',
            render: (_: any) => (
                <Select defaultValue="Option1" disabled={props.disable || false}>
                    <Option value="Option1">Size 1</Option>
                    <Option value="Option2">Size 2</Option>
                    <Option value="Option3">Size 3</Option>
                </Select>
            ),
        },
        {
            title: 'Seal No',
            dataIndex: 'SealNo',
            render: (_: any, record: DataItem) => (
                <Input value={record.SealNo} disabled={props.disable || false}
                    onChange={(e) => handleInputChange(e, record.key, 'SealNo')} />
            ),
        },
        {
            title: 'No.Of.Package',
            dataIndex: 'NoOfPackage',
            render: (_: any, record: DataItem) => (
                <Input value={record.NoOfPackage} disabled={props.disable || false}
                    onChange={(e) => handleInputChange(e, record.key, 'NoOfPackage')} />
            ),
        },
        {
            title: 'Package Type',
            dataIndex: 'PackageType',
            render: (_: any) => (
                <Select defaultValue="Option1" disabled={props.disable || false}>
                    <Option value="Option1">Option 1</Option>
                    <Option value="Option2">Option 2</Option>
                    <Option value="Option3">Option 3</Option>
                </Select>
            ),
        },

        {
            title: 'Gr Wt',
            dataIndex: 'GrWt',
            render: (_: any, record: DataItem) => (
                <Input value={record.GrWt.toFixed(2)} disabled={props.disable || false}
                    onChange={(e) => handleInputChange(e, record.key, 'GrWt')} />
            ),
        },
        {
            title: 'Volume',
            dataIndex: 'Volume',
            render: (_: any, record: DataItem) => (
                <Input value={record.Volume.toFixed(2)} disabled={props.disable || false}
                    onChange={(e) => handleInputChange(e, record.key, 'Volume')} />
            ),
        },
        {
            title: 'Haz',
            dataIndex: 'Haz',
            render: (_: any, record: DataItem) => (
                <Switch disabled={props.disable || false}
                    onChange={(e) => handleInputChange(e, record.key, 'Haz')}
                    checked={record.Haz} checkedChildren="Yes" unCheckedChildren="No" />
            ),
        },
        {
            title: 'AgentSealNo',
            dataIndex: 'AgentSealNo',
            render: (_: any, record: DataItem) => (
                <Input value={record.Volume} disabled={props.disable || false}
                    onChange={(e) => handleInputChange(e, record.key, 'AgentSealNo')} />
            ),
        },
    ];

    if (!props.actionRow) {
        columns.unshift({
            title: 'Select',
            dataIndex: 'Select',
            render: (_: any, record: DataItem) => (
                <Switch
                    onChange={(e) => handleInputChange(e, record.key, 'Select')}
                    checked={record.Select} checkedChildren="Yes" unCheckedChildren="No" />
            ),
        },)
    }

    if (props.actionRow) {
        columns.push({
            title: () => (
                <Button type="primary" onClick={handleAddRow}>
                    Add New
                </Button>
            ),
            dataIndex: 'action',
            // width: '100',
            align: 'center',
            render: (_: any, record: DataItem) => (
                // <Button type="link" onClick={() => handleRemoveRow(record.key)}><MinusCircleOutlined className="text-red-700 p-0" /></Button>
                <MinusCircleOutlined style={{width: "20px"}} className="text-red-700 p-0" onClick={() => handleRemoveRow(record.key)} />
            ),
        })
    }

    const rowSelection = {
        onChange: (selectedRowKeys: React.Key[], selectedRows: any) => {
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
        },
        getCheckboxProps: (record: any) => ({
            disabled: record.name === 'Disabled User', // Column configuration not to be checked
            name: record.name,
        }),
    };

    return (
        <Table
            rowSelection={props.checkboxEnable ? {
                type: "checkbox",
                ...rowSelection,
            } : undefined}
            dataSource={data}
            columns={columns}
            pagination={false}
            bordered
        />
    );
};

export default ContainerTable;
