
import { useState } from "react";
import { Flex, Popover, Space, Input, Select, Button } from 'antd';
import { FilterOutlined, CloseOutlined, MinusCircleOutlined } from '@ant-design/icons';
import AppButton from "@Components/AppButton";
import AppTypography from "@Components/AppTypography";
import "./AdvanceFilter.css"
function AdvanceFilter(props: any) {

    const [dropdowns, setDropdowns] = useState([{ selectedAndOr: "", selectedColumn: "", selectedCondition: "", selectedValue: "" }]);
    const handleAddRow = () => {
        setDropdowns([...dropdowns, { selectedAndOr: "", selectedColumn: "", selectedCondition: "", selectedValue: "" }]);
    };

    const handleMenuClick = (index: number, type: string, clickedLabel: string) => {
        // Update the selected value of the clicked dropdown based on its type
        const updatedDropdowns = [...dropdowns];
        if (type === "andOr") {
            updatedDropdowns[index].selectedAndOr = clickedLabel
        } else if (type === "column") {
            updatedDropdowns[index].selectedColumn = clickedLabel;
        } else if (type === "condition") {
            updatedDropdowns[index].selectedCondition = clickedLabel;
        } else if (type === "value") {
            updatedDropdowns[index].selectedValue = clickedLabel;
        }
        setDropdowns(updatedDropdowns);
    };

    const handleDropdownClick = (index: number, type: string) => {
        return (e: any) => {
            let clickedItem
            if (type === "andOr") {
                clickedItem = andOrOptions?.find(item => item?.value === e);
            }
            else if (type === "column") {
                clickedItem = columnsOptions?.find(item => item?.value === e);
            }
            else if (type === "condition") {
                clickedItem = conditionOptions?.find(item => item?.value === e);
            }
            const clickedValue = clickedItem?.value || ""; // Get the label of the clicked item
            handleMenuClick(index, type, clickedValue);
        };
    };

    const columnsOptions = [
        {
            label: '1st menu item',
            value: 'first',
        },
        {
            label: '2nd menu item',
            value: 'second',
        },
        {
            label: '3rd menu item',
            value: 'thisr',
        },
    ];

    const conditionOptions = [
        {
            label: 'Condition1',
            value: 'con1',
        },
        {
            label: 'Condition2',
            value: 'con2',
        },
        {
            label: 'Condition3',
            value: 'con3',
        },
    ];


    const andOrOptions = [
        {
            label: 'And',
            value: 'and',
        },
        {
            label: 'Or',
            value: 'or',
        },
    ];

    const closeRowHandler = (index: any, type: String) => {
        const updatedDropdowns = [...dropdowns];
        if (type === 'clearAll') {
            updatedDropdowns.splice(1);
            setDropdowns([{ selectedAndOr: " ", selectedColumn: "", selectedCondition: "", selectedValue: "" }]);
        } else {
            updatedDropdowns.splice(index, 1);
        }
        setDropdowns(updatedDropdowns);
    }

    const createStringHandler = () => {
        const result = dropdowns.map((item, index) => {
            if (index === 0) {
                return `${"Where"} ${item.selectedColumn} ${item.selectedCondition} ${item.selectedValue}`;
            } else {
                return `${item.selectedAndOr} ${item.selectedColumn} ${item.selectedCondition} ${item.selectedValue}`;
            }
        });
        const resultString = result.join(' ');
        props.setFilterQuery(resultString)
    }

    const inputRows = dropdowns.map((dropdown, index) => (
        <Flex key={index} style={{ marginBottom: 10 }}>
            <Space className="w-full">
                {index === 0 ?
                    <span className="block" style={{ width: "90px" }}>Where:</span> :
                    <Select
                        style={{ width: 90 }}
                        placeholder="And/Or"
                        options={andOrOptions}
                        value={dropdown.selectedAndOr == "" ? null : dropdown.selectedAndOr}
                        onChange={handleDropdownClick(index, "andOr")}
                    />
                }

                <Select
                    style={{ width: 150 }}
                    placeholder="Select Column"
                    options={columnsOptions}
                    value={dropdown.selectedColumn === "" ? null : dropdown.selectedColumn}
                    onChange={handleDropdownClick(index, "column")}
                />

                <Select
                    style={{ width: 150 }}
                    placeholder="Select Condition"
                    options={conditionOptions}
                    value={dropdown.selectedCondition === "" ? null : dropdown.selectedCondition}
                    onChange={handleDropdownClick(index, "condition")}
                />

                <Input
                    placeholder="value"
                    type="primary"
                    value={dropdown.selectedValue === "" ? "" : dropdown.selectedValue}
                    onChange={(e) => { handleMenuClick(index, "value", e.target.value) }}
                />

                {index > 0 &&
                    <MinusCircleOutlined className="text-red-700" onClick={() => closeRowHandler(index, "single")} />
                }
            </Space>
        </Flex>
    ));

    return (
        <Popover
            destroyTooltipOnHide
            placement="bottomLeft"
            trigger="click"
            overlayInnerStyle={{ padding: "15px 20px" }}
            title={
                <Flex align="center" justify="space-between">
                    <AppTypography type="Title" className="text-lg">
                        Advanced Filters
                    </AppTypography>
                    <AppTypography type="Text" className="mb-0 flex items-center gap-1 text-secondary cursor-pointer"
                        onClick={() => { closeRowHandler(1, "clearAll") }}>
                        <CloseOutlined style={{ fontSize: "12px" }} />Clear All
                    </AppTypography>
                </Flex>
            }
            content={
                <div>
                    <Space direction="vertical" style={{ maxHeight: '200px' }} className="overflow-y-auto my-3 gap-0">{inputRows}</Space> {/* Set max height and overflow-y to enable scrolling */}
                    <Flex align="center" justify="space-between">
                        <AppButton type="link" onClick={handleAddRow} className="p-0 underline">+ New Filter</AppButton>
                        <Button  type='primary' onClick={createStringHandler}>Apply</Button>
                    </Flex>
                </div>
            }
        >
            <Flex>
                <Button icon={<FilterOutlined />} type="primary">
                    <span className="font-semibold">Filter</span>
                </Button>
            </Flex>
        </Popover>
    );
}

export default AdvanceFilter;