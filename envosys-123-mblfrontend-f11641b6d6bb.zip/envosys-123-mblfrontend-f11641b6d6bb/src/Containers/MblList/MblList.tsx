import { useState } from 'react';
import AppRoute from '@Routes/AppRoute'
import { useNavigate } from 'react-router-dom'
import { Button, Card, Flex, Space, Tabs, Tag, Tooltip } from 'antd';
import GenericTable from "@Components/Table/GenericTable";
import ColumnConfig from "@Components/ColumnConfig/columnConfig";
import { ExportExcel } from '@Assets/index'
import AdvanceFilter from './Component/AdvanceFilter'
import { DeleteOutlined, CopyOutlined, DownOutlined, PlusOutlined } from '@ant-design/icons';
import "./mblList.css";
import TabPane from 'antd/es/tabs/TabPane';

const columns = ['MasterBlNumber','MasterBLDate', 'AgentName', 'Line', 'Vessel', 'Voyage', 'POL', 'POD',
    'VesselArrivalDate', 'ShipmentType'];

const data = [
    {
        key: 1,
        MasterBlNumber:"001",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date  ',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 2,
        MasterBlNumber:"002",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 3,
        MasterBlNumber:"003",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 4,
        MasterBlNumber:"004",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 5,
        MasterBlNumber:"005",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 6,
        MasterBlNumber:"006",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 7,
        MasterBlNumber:"007",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 8,
        MasterBlNumber:"008",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 9,
        MasterBlNumber:"009",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
    {
        key: 10,
        MasterBlNumber:"0010",
        MasterBLDate: '08-05-2024',
        AgentName: 'Test Date',
        Line: 'Test Date',
        Vessel: 'Test Date',
        Voyage: 'Test Date',
        POL: 'Test Date',
        POD: 'Test Date',
        VesselArrivalDate: '08-05-2024',
        ShipmentType: 'Test Date',
        ETD: 'Test Date'
    },
];

function MblList() {
    const navigate = useNavigate()
    const [columnsOptions, setColumnsOptions] = useState(columns);
    const [selectedColumns, setSelectedColumns] = useState([]);
    const [filterQuery, setFilterQuery] = useState("");

    const handleKeywordChange = (selectedItems: any) => {
        setSelectedColumns(selectedItems);
    };

    // on filter apply buttin for show the table columns
    const onApply = () => {
        if (selectedColumns.length > 0) {
            setColumnsOptions(selectedColumns)
        } else {
            setColumnsOptions(columns)
        }
    };

    const newMblClickHandler = () => {
        navigate(AppRoute.MblForm)
    }

    return (
        <>
            <Card styles={{
                body: {
                    padding: 0
                }
            }}>
                <Tabs defaultActiveKey="1" tabBarStyle={{
                    margin: 0,
                    padding: "10px 15px"
                }}>
                    <TabPane tab="Master B/L List" key="1">
                        <Flex justify='space-between' className='p-4'>
                            {/* Left ACtion Buttons */}
                            <Space align='center'>
                                <Button type='primary' icon={<PlusOutlined />} onClick={newMblClickHandler} >
                                    Add
                                </Button>

                                <Button type='primary' icon={<CopyOutlined />} >
                                    Copy
                                </Button>

                                <Button type='primary' icon={<DeleteOutlined />} >
                                    Delete
                                </Button>
                            </Space>

                            {/* Right Menu */}
                            <Flex align='center' gap={10}>
                                {filterQuery.length > 1 &&
                                    <Tooltip className='filter-query truncate' title={filterQuery}>
                                        <Tag closable className='text-secondary'>{filterQuery}</Tag>
                                    </Tooltip>
                                }

                                <AdvanceFilter
                                    setFilterQuery={setFilterQuery}
                                />

                                <ColumnConfig
                                    options={columns}
                                    value={selectedColumns}
                                    onChange={handleKeywordChange}
                                    onApply={onApply}
                                />

                                <Button>
                                    <Space>
                                        <img src={ExportExcel} alt='Excel' /> Export <DownOutlined />
                                    </Space>
                                </Button>
                            </Flex>
                        </Flex>
                        <GenericTable columns={columnsOptions} data={data} />
                    </TabPane>
                    <TabPane tab="House B/L List" key="2">
                        <Flex className="w-full h-96" align="center" justify="center">
                            <h1 className="text-2xl font-bold">Coming Soon !</h1>
                        </Flex>
                    </TabPane>
                </Tabs>
            </Card>
        </>
    );
}

export default MblList;