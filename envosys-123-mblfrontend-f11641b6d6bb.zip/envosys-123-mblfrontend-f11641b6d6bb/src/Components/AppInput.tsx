import { Input, InputProps } from "antd";

interface CommonInputProps extends InputProps {
    onlyNumber?: boolean;
    isWeight?: boolean;
}

const AppInput: React.FC<CommonInputProps> = (props) => {
    const { onlyNumber = false, isWeight = false, ...otherProps } = props;

    const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (isWeight) {
            e.target.value = e.target.value.replace(/[^0-9.]/g, '');
            const dotCount = e.target.value.split('.').length - 1;
            if (dotCount > 1) {
                e.target.value = e.target.value.slice(0, e.target.value.lastIndexOf('.'));
            }
            props?.onChange?.(e);
        } else if (onlyNumber) {
            const numericValue = e.target.value.replace(/\D/g, "");
            e.target.value = numericValue;
            props?.onChange?.(e);
        } else {
            props?.onChange?.(e);
        }
    };

    return <Input autoComplete="off" style={{ fontSize: "14px" }} {...otherProps} onChange={onChange} />;
};

export default AppInput;
