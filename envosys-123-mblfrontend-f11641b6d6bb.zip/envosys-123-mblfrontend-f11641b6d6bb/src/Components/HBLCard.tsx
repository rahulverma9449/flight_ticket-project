import { Space, Tag, Tooltip, Typography } from "antd";
import { FileTextOutlined } from "@ant-design/icons"

type IProps = {
    hblNo: string;
    cardColor?: string;
    cardActive?: boolean
};

function HBLCard({ hblNo = "abcd12345678", cardColor = "bg-yellow-500" }: IProps) {
    // cardActive = false
    return (
        <Tooltip placement="bottomLeft" color="white"
            title={
                <Space direction="vertical" >
                    <Typography.Title level={5} className="uppercase text-theme font-bold">{hblNo}</Typography.Title>
                    <Typography.Text> COMPANY NAME</Typography.Text>
                    <Typography.Text> PKG:2</Typography.Text>
                    <Typography.Text> Weight: 1000KG</Typography.Text>
                    <Typography.Text> Measurement:3.7</Typography.Text>
                </Space>
            }>
            <Tag
                className={`${cardColor} rounded-full uppercase text-white py-1`}
                icon={<FileTextOutlined style={{ fontSize: "16px", verticalAlign: "text-bottom" }} />}
                bordered={false}
            >
                {hblNo}
            </Tag>

            {/* {cardActive &&
          <Space direction="vertical" className="px-2 gap-0 mb-10">
            <AppTypography
              type="Title"
              className="uppercase font-semibold text-md"
            >
              Company Name Pvt Ltd
            </AppTypography>
            <AppTypography
              type="Title"
              className="uppercase font-semibold text-md"
            >
              Company Name Pvt Ltd
            </AppTypography>
          </Space>
        }


        <Flex vertical>
          <Flex className="border-t-white border-t border-opacity-60">
            <AppTypography
              type="Title"
              className="uppercase grow px-2"
            >
              PKG: 2
            </AppTypography>
            <AppTypography
              type="Title"
              className="grow px-2 border-t-white border-l border-opacity-60"
            >
              Weight: 1,000.00 KG
            </AppTypography>
          </Flex>

          <Space className="border-t-white border-t border-opacity-60">
            <AppTypography
              type="Title"
              className="px-2"
            >
              Measurement: 3.75 CBM
            </AppTypography>
          </Space>
        </Flex> */}
        </Tooltip>

    );
}

export default HBLCard;
