import { useState } from 'react';
import { AutoComplete } from 'antd';
import './FloatInput/floatInput.css'; // Import CSS file for styling if needed
import { DownOutlined } from '@ant-design/icons';

const MyAutoComplete = (props: any) => {
    const [focus, setFocus] = useState(false);
    const { label, value, placeholder, required, options, ...otherProps } = props;

    const isOccupied = focus || (value && value.length !== 0);
    const labelClass = isOccupied ? "label as-label" : "label as-placeholder";
    const requiredMark = required ? <span className="text-danger">*</span> : null;

    const handleFocus = () => {
        setFocus(true);
    }

    const handleBlur = () => {
        if (!value || value === '') {
            setFocus(false);
        }
    }

    const handleSelect = (value: any, type: any) => {
        setFocus(true);
        props.handleSelectValue(value, type);
    }

    const handleChange = (value: any) => {
        setFocus(true);
        props.handleChange(value)
    }


    return (
        <div className="float-label" onBlur={handleBlur} onFocus={handleFocus}>
            <AutoComplete
                {...otherProps} // Pass other props to AutoComplete component
                options={options.map((option: any) => ({
                    value: option.value,
                    label: (
                        <div>
                            <span>{option.value}</span>
                        </div>
                    ),
                }))}
                filterOption={(inputValue, option: any) =>
                    option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1
                }
                suffixIcon={<DownOutlined className='text-secondary' />}
                defaultValue={value}
                style={{ width: 150 }}
                size="large"
                onSelect={(value) => handleSelect(value, otherProps.type)} // Pass type as an argument
                onChange={handleChange}
            />
            <label className={labelClass}>
                {isOccupied ? label : placeholder} {requiredMark}
            </label>
        </div>
    );
};

export default MyAutoComplete;