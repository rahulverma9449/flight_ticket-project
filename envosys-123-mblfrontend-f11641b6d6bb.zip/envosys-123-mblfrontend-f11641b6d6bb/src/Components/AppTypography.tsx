import { ConfigProvider, Typography } from "antd";
import { NavLink } from "react-router-dom";

const { Title, Paragraph, Text } = Typography;

interface AppTitleProps {
  type: "Title" | "Paragraph" | "Text" | "NavLink";
  color?: string;
  children: React.ReactNode;
  fontsize?: number;
  level?: 1 | 2 | 3 | 4 | 5;
  strong?: boolean;
  lineHeight?: number;
  onClick?: () => void;
  appRoutePath?: string;
  fontWeight?: string;
  fontFamily?: string;
  titleMarginBottom?: number;
  fontWeightStrong?: number;
  className?: string;
  style?: any;
  margin?: number;
  target?: React.HTMLAttributeAnchorTarget | undefined;
}

const AppTypography: React.FC<AppTitleProps> = (props) => {
  // const theme: ThemeConfig | any = {};
  // if (props?.color) {
  //   theme.token.colorText = props.color;
  // }
  // if (props?.fontsize) {
  //   theme.token.fontSize = props.fontsize;
  // }
  // if (props?.lineHeight) {
  //   theme.token.lineHeight = props.lineHeight;
  // }
  // if (props?.fontFamily) {
  //   theme.token.fontFamilyCode = props.fontFamily;
  // }
  // if (props?.fontWeightStrong) {
  //   theme.token.fontWeightStrong = props.fontWeightStrong;
  // }

  // if (props?.titleMarginBottom) {
  //   theme.components.titleMarginBottom = props.titleMarginBottom
  // }

  return (
    <>
      <ConfigProvider
        // theme={theme}
        theme={{
          token: {
            colorText: props.color,
            fontSize: props.fontsize,
            lineHeight: props.lineHeight,
            fontFamilyCode: props.fontFamily,
            fontWeightStrong: props.fontWeightStrong,
          },
          components: {
            Typography: {
              titleMarginBottom: props.titleMarginBottom,
              titleMarginTop: 0,
            },
          },
        }}
      >
        {props.type === "Title" && (
          <Title
            onClick={props.onClick}
            style={{
              margin: props.margin,
              ...props.style,
              fontFamily: props.fontFamily,
            }}
            className={props.className}
            level={props.level}
          >
            {props.children}
          </Title>
        )}
        {props.type === "Text" && (
          <Text
            strong={props.strong}
            onClick={props?.onClick}
            className={props.className}
            style={{ ...props.style }}
          >
            {props.children}
          </Text>
        )}
        {props.type === "Paragraph" && (
          <Paragraph
            onClick={props?.onClick}
            strong={props.strong}
            className={props.className}
            style={{ margin: props.margin, ...props.style }}
          >
            {props.children}
          </Paragraph>
        )}
        {props.type === "NavLink" && (
          <NavLink
            target={props.target}
            to={props.appRoutePath || ""}
            style={{
              color: props.color,
              fontSize: props.fontsize,
              lineHeight: props.lineHeight,
              fontWeight: props.fontWeight,
            }}
            className={props?.className}
            onClick={props?.onClick}
          >
            {props.children}
          </NavLink>
        )}
      </ConfigProvider>
    </>
  );
};

export default AppTypography;
