import React, { useEffect, useRef, useState } from "react";
interface Props {
    backgroundColor: string;
    foregroundColor: string;
    showValue: boolean;
    percentage: number;
}

const CircleProgressBar: React.FC<Props> = ({
    backgroundColor,
    foregroundColor,
    showValue,
    percentage,
}) => {
    const [radius] = useState("40.5");
    const [dasharray, setDasharray] = useState(0);
    const [dashoffset, setDashoffset] = useState(0);
    const ref = useRef<SVGSVGElement>(null);
    function generateMeter(w: any) {
        setDasharray(((w * Number(radius)) / 100) * Math.PI * 2);
        setTimeout(() => {
            setDashoffset(((100 - percentage) / 100) * dasharray);
        }, 100);
    }

    useEffect(() => {
        if (ref && ref.current) {
            let _w = ref.current.clientWidth;
            generateMeter(_w);
        }
    }, [ref, dasharray]);
    return (
        <svg
            ref={ref}
            id="svg"
            width="100"
            height="100"
            viewBox="0 0 100 100"
            version="1.1"
            xmlns="http://www.w3.org/2000/svg"
            style={{ width: "80%", height: "80%" }}
        >
            <circle
                r={`${radius}%`}
                cx="50%"
                cy="50%"
                fill={backgroundColor}
                strokeWidth="5%"
                stroke={backgroundColor}
            ></circle>
            <circle
                id="bar"
                r={`${radius}%`}
                cx="50%"
                cy="50%"
                fill="transparent"
                strokeDasharray={dasharray}
                strokeDashoffset={dashoffset}
                strokeWidth="20%"
                stroke={foregroundColor}
            ></circle>
            <text
                x="50%"
                y="50%"
                dominantBaseline="middle"
                textAnchor="middle"
                fill={showValue ? foregroundColor : "transparent"}
            >
                {percentage}%
            </text>
        </svg>
    );
};

export default CircleProgressBar;
