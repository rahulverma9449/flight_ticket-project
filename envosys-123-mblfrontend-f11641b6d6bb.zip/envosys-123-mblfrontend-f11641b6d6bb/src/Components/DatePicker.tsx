import { useState } from 'react';
import { DatePicker } from 'antd';
import './FloatInput/floatInput.css'; // Import CSS file for styling if needed
import { CalendarOutlined } from '@ant-design/icons';

const DatePickerInput = (props: any) => {
    const [focus, setFocus] = useState(false);
    const { label, value, placeholder, required, ...otherProps } = props;

    const isOccupied = focus || (value && value.length !== 0);

    const labelClass = isOccupied ? "label as-label" : "label as-placeholder";
    const requiredMark = required ? <span className="text-danger">*</span> : null;

    const dateFormatList = ['DD/MM/YYYY', 'DD/MM/YY', 'DD-MM-YYYY', 'DD-MM-YY'];

    const handleFocus = () => {
        setFocus(true);
    }

    const handleBlur = () => {
        if (!value || value === '') {
            setFocus(false);
        }
    }

    const handleChange = (date: any, dateString: any, type: any) => {
        setFocus(true);
        props.handleSelectValue(dateString, type);
        console.log(date);
    }

    return (
        <div className="float-label" onBlur={handleBlur} onFocus={handleFocus}>
            <DatePicker
                {...otherProps}
                value={value}
                placeholder={label}
                suffixIcon={<CalendarOutlined className='text-secondary' />}
                onChange={(date, dateString) => handleChange(date, dateString, otherProps.type)}
                format={dateFormatList}
            />
            <label className={labelClass}>
                {isOccupied ? label : placeholder} {requiredMark}
            </label>
        </div>
    );
};

export default DatePickerInput;
