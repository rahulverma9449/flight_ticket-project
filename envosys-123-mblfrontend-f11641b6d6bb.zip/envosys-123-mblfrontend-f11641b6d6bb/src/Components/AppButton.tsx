// CommonButton.tsx
import React, { ReactNode } from "react";
import { Button } from "antd";
import { ButtonProps } from "antd/es/button";

interface CommonButtonProps extends ButtonProps {
  children: ReactNode;
  fontWeight?: 100 | 200 | 300 | 400 | 500 | 600 | 700 | 800 | 900,
  fontSize?: string,
  color?: "blue" | "grey"
}

const CommonButton: React.FC<CommonButtonProps> = ({
  children,
  ...restProps
}) => {
  const { fontWeight = 600, fontSize = "14px", className = ""} = restProps;

  return (
      <Button style={{ fontWeight: fontWeight, fontSize: fontSize, height: "auto" }} className={className} {...restProps}>{children}</Button>
  );
};

export default CommonButton;
