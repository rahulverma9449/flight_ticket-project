import { ReactNode } from "react";

type IProps = {
  children: ReactNode;
};

function PageLayout({ children }: IProps) {
  return <div className="page-layout">{children}</div>;
}

export default PageLayout;
