import { ReactNode } from 'react'

type IBox = {
    children: ReactNode
}

function Box({ children }: IBox) {
    return (
        <div className='box'>
            {children}
        </div>
    )
}

export default Box