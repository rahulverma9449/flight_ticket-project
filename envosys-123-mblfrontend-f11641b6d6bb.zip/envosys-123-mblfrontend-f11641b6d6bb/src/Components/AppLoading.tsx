// LoadingAnimation.tsx

import React from "react";
import styles from "./LoadingAnimation.module.css";

interface LoadingAnimationProps {}

const LoadingAnimation: React.FC<LoadingAnimationProps> = ({}) => {
  const letters = "Loading";
  return (
    <div className={styles.ag}>
      {letters.split("").map((letter, index) => (
        <span key={index}>{letter}</span>
      ))}
    </div>
  );
};

export default LoadingAnimation;
