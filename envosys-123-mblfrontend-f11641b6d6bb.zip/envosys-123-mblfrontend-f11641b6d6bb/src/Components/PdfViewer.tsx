import { Modal, ModalProps } from 'antd';

type IProps = ModalProps & {
    pdfDetails: any
    downloadPDF: (doc: string) => void
}

function PdfViewer(props: IProps) {
    const {
        open,
        onCancel,
        pdfDetails,
        // downloadPDF
    } = props
    return (
        <Modal
            open={open}
            width="690px"
            footer={null}
            onCancel={onCancel}
        >
            <div>
                {/* <button
                    type="button"
                    className="btn_black"
                    onClick={() => {
                        downloadPDF(pdfDetails?.doc);
                    }}
                >
                    Download
                </button> */}
                <img
                    style={{ width: "100%", marginTop: "1rem" }}
                    src={`data:image/png;base64,${pdfDetails?.doc}`}
                />
            </div>
        </Modal>
    )
}

export default PdfViewer