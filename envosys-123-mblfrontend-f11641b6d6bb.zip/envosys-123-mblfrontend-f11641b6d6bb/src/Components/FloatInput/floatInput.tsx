import { useState } from "react";
import { Input } from "antd";
import "./floatInput.css";

const { TextArea } = Input;

const FloatInput = (props: any) => {
    const [focus, setFocus] = useState(false);
    let { label, value, placeholder, required, isTextArea = false, style, wrapperStyle } = props;


    if (!placeholder) placeholder = label;
    const isOccupied = focus || (value && value.length !== 0);
    const labelClass = isOccupied ? "label as-label" : "label as-placeholder";
    const requiredMark = required ? <span className="text-danger">*</span> : null;

    // const onChange = (e: any) => {
    //     if (props.isWeight) {
    //         e.target.value = e.target.value.replace(/[^0-9.]/g, '');
    //         const dotCount = e.target.value.split('.').length - 1;
    //         if (dotCount > 1) {
    //             e.target.value = e.target.value.slice(0, e.target.value.lastIndexOf('.'));
    //         }
    //         props?.onChange?.(e);
    //     } else if (props.onlyNumber) {
    //         const numericValue = e.target.value.replace(/\D/g, "");
    //         e.target.value = numericValue;
    //         props?.onChange?.(e);
    //     } else {
    //         props?.onChange?.(e);
    //     }
    // };
    return (
        <div
            className="float-label"
            onBlur={() => setFocus(false)}
            onFocus={() => setFocus(true)}
            style={wrapperStyle}
        >
            {isTextArea ?

                <TextArea
                    autoSize={{ minRows: props.minRow || 2, maxRows: props.maxRow || 6 }}
                    style={style}
                /> :

                <Input
                    onChange={props.onChange}
                    type={props.type}
                    defaultValue={value}
                    size="large"
                />}

            <label className={labelClass}>
                {isOccupied ? label : placeholder} {requiredMark}
            </label>
        </div>
    );
};

export default FloatInput;
