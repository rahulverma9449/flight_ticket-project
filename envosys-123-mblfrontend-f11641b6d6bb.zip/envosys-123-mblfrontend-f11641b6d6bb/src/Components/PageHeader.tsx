import { ReactNode } from "react";
import AppTypography from "./AppTypography";

type IPageHeader = {
  children: ReactNode;
};

function PageHeader({ children }: IPageHeader) {
  return (
    <AppTypography type="Title" className="pageheader text-xl" level={3}>
      {children}
    </AppTypography>
  );
}

export default PageHeader;
