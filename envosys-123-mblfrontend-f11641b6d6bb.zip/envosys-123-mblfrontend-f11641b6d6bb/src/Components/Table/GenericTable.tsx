import React from 'react';
import { Flex, Table, Tooltip } from 'antd';
import type { TableColumnsType } from 'antd';
import { EditOutlined } from '@ant-design/icons';
import AppButton from "@Components/AppButton";
import './Table.css'

interface DataType {
    key: React.Key;
    [key: string]: any;
}

interface Props {
    columns: string[];
    data: DataType[];
}

const GenericTable = (props: Props) => {

    const tableColumns: TableColumnsType<DataType> = props.columns.map((columnName: string) => ({
        title: columnName,
        dataIndex: columnName,
        key: columnName,
        sorter: (a: DataType, b: DataType) => {
            const aValue = a[columnName];
            const bValue = b[columnName];
            // Check if values are strings
            if (typeof aValue === 'string' && typeof bValue === 'string') {
                return aValue.localeCompare(bValue); // Sort string values
            } else {
                return aValue - bValue; // Sort numeric values
            }
        },
        width: 170,
        render: (text: any) => (
            <Tooltip title={text} placement="bottom">
                <div style={{ maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                    {text}
                </div>
            </Tooltip>
        ),
    }));

    // Add action column
    const actionColumn: any = {
        title: 'Action',
        key: 'action',
        width: 110,
        fixed: 'right',
        render: (record: any) => (
            <Flex gap={10}>
                <AppButton onClick={() => handleAction(record)} className='px-2'>
                    <EditOutlined style={{ fontSize: "16px", verticalAlign: "baseline" }} />Edit
                </AppButton>
            </Flex>
        ),
    };
    tableColumns.push(actionColumn);

    // Function to handle action button click
    const handleAction = (record: DataType) => {
        console.log('Action clicked for record:', record);
    };

    const rowSelection = {
        onChange: (selectedRowKeys: React.Key[], selectedRows: DataType[]) => {
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
        },
        getCheckboxProps: (record: DataType) => ({
            disabled: record.name === 'Disabled User', // Column configuration not to be checked
            name: record.name,
        }),
    };

    // Function to determine row class name for alternate rows
    const getRowClassName = (record: DataType, index: number) => {
        return index % 2 === 0 ? 'even-row' : 'odd-row';
        console.log(record)
    };

    return (
        <Table
            rowSelection={{
                type: "checkbox",
                ...rowSelection,
            }}
            columns={tableColumns}
            rowClassName={getRowClassName}// Apply alternate row colors
            // for expend row ad colapse
            // expandable={{
            //     expandedRowRender: (record) => (
            //         <div>
            //             <p style={{ marginLeft: 90 }}>{record.Description}</p>
            //         </div>
            //     ),
            //     rowExpandable: (record) => record.Name !== 'Not Expandable',
            //     expandIcon: ({ expanded, onExpand, record }) =>
            //         expanded ? (
            //             <RightOutlined rotate={90} className='text-theme' onClick={(e) => onExpand(record, e)} style={{ fontSize: "12px" }} />
            //         ) : (
            //             <RightOutlined className='text-theme' onClick={(e) => onExpand(record, e)} style={{ fontSize: "12px" }} />
            //         ),
            // }}
            scroll={{ x: 1500, y: 400 }}
            dataSource={props.data}
            pagination={{ position: ['bottomRight'], pageSize: 10 }}
        />
    );
};

export default GenericTable;
