import React, { useState, useEffect } from "react";
import { Checkbox, Popover, Flex, Button } from "antd";
import { SettingOutlined } from '@ant-design/icons'

interface CheckboxMenuProps {
    options: string[];
    value?: string[];
    onChange: (value: string[]) => void;
    onApply: () => void;
}

const ColumnConfig: React.FC<CheckboxMenuProps> = ({ options, value = [], onChange, onApply }) => {
    const [selectedItems, setSelectedItems] = useState<string[]>(value);

    useEffect(() => {
        if (value && value.length) {
            setSelectedItems([...value]);
        }
    }, [value]);

    const onChangeHandler = (selection: string[]) => {
        setSelectedItems([...selection]);
        return onChange(selection);
    };

    const checkboxRender = () => {
        const groups = options.map((_e, i: any) => (i % 10 === 0 ? options.slice(i, i + 10) : null))
            .filter((e) => e);
        return (
            <Flex vertical>
                <Checkbox.Group onChange={onChangeHandler} value={selectedItems}>
                    {groups.map((group: any, i) => (
                        <Flex vertical key={"checkbox-group-" + i}>
                            {group.map((label: any) => (
                                <Checkbox
                                    key={label}
                                    value={label}
                                >
                                    {label}
                                </Checkbox>
                            ))}
                        </Flex>
                    ))}
                </Checkbox.Group>
                <Button type="primary" onClick={onApply} style={{ marginTop: 10 }}>
                    Apply
                </Button>
            </Flex>
        );
    };

    return (
        <Popover content={checkboxRender()} trigger="click" placement="bottomLeft">
            <Button type="primary" icon={<SettingOutlined />} >
                Config
            </Button>
        </Popover>
    );
};

export default ColumnConfig;