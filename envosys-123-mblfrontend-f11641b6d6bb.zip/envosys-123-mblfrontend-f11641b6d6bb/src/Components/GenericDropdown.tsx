import React, { useState } from 'react';
import { Dropdown, Button, Space } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import type { MenuProps } from 'antd';

interface Option {
    label: string;
    key: string;
}

interface Props {
    items: Option[];
    onSelect: (key: String) => void;
    defaultValue: string;
}

const GenericDropdown: React.FC<Props> = ({ items, onSelect, defaultValue }) => {
    const [selectedOption, setSelectedOption] = useState("");

    const onClick: MenuProps['onClick'] = ({ key }) => {
        setSelectedOption(key);
        onSelect(key);
    };

    return (
        <Dropdown menu={{ items, onClick }}>
            <Button className='flex items-center' style={{ backgroundColor: "#919EAB14", border: 0 }} onClick={(e) => e.preventDefault()}>
                <Space>
                    {selectedOption || defaultValue || "select"}
                    <DownOutlined />
                </Space>
            </Button>
        </Dropdown>
    );
};

export default GenericDropdown;