import { Breadcrumb } from 'antd';
import { useLocation, Link } from "react-router-dom";
import { HomeOutlined } from '@ant-design/icons';
const AppBreadcrumb = () => {
    const location = useLocation();
    const breadcrumbView = () => {
        const { pathname } = location
        const pathnames = pathname.split("/").filter((item) => item)
        return (
            <Breadcrumb className='mb-3 items-center' separator={"/"}>
                {pathnames.length > 0 ? (
                    <Breadcrumb.Item>
                        <Link to="/dashboard">
                            <HomeOutlined style={{verticalAlign: "text-top"}} className='mr-1 text-theme' />
                            Home
                        </Link>
                    </Breadcrumb.Item>
                ) : (
                    <Breadcrumb.Item>
                        <HomeOutlined />
                        Home
                    </Breadcrumb.Item>
                )}
                {pathnames.map((name, index) => {
                    // const routTo = `/${pathnames.slice(0, index + 1).join("/")}`
                    const isLast = index === pathnames.length - 1;
                    return isLast ? (
                        <Breadcrumb.Item>{`${name.charAt(0).toUpperCase()}${name.slice(1)}`}</Breadcrumb.Item>
                    ) : (
                        <Breadcrumb.Item>
                            <Link to={"#"}>{`${name.charAt(0).toUpperCase()}${name.slice(1)}`}</Link>
                            {/* <Link to={`${routTo}`}>{name}</Link> */}
                        </Breadcrumb.Item>
                    )
                })}
            </Breadcrumb>
        )
    }
    return (
        <>
            {breadcrumbView()}
        </>
    )
}

export default AppBreadcrumb;