import { useState, createContext,  } from 'react'
import './App.css';
import './style.css';
import { BrowserRouter } from "react-router-dom";
import Navigator from "@Routes/Navigator";
import { ConfigProvider, theme } from 'antd';
import { themeConfigLight, themeConfigDark } from '@Static/CustomTheme';

export const context = createContext({});

function App() {
    const [appTheme, setAppTheme] = useState(true);
    const value = { appTheme, setAppTheme };
    
    const customTheme = appTheme ? { ...themeConfigLight,  algorithm: theme.defaultAlgorithm, } : { ...themeConfigDark, algorithm: theme.darkAlgorithm };

    return (
        <>
            <ConfigProvider theme={customTheme}>
                <context.Provider value={value}>
                    <BrowserRouter>
                        <Navigator />
                    </BrowserRouter>
                </context.Provider>
            </ConfigProvider>
        </>
    )
}

export default App
