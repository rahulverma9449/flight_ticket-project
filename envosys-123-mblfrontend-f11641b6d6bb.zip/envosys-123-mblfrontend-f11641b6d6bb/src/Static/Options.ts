export const businessType = [
    { label: 'Private limited Company', value: 'Private limited Company' },
    { label: 'Proprietorship', value: 'Proprietorship' },
    { label: 'Partnership', value: 'Partnership' },
    { label: 'Public Limited', value: 'Public Limited' },
    { label: 'LLP', value: 'LLP' },
    { label: 'Trust', value: 'Trust' },
    { label: 'Society', value: 'Society' },
    { label: 'NGO', value: 'NGO' },
    { label: 'Other', value: 'Other' },
]

export const commodities = [
    { label: 'Rice', value: 'Rice' },
    { label: 'Wheat', value: 'Wheat' },
    { label: 'Paddy', value: 'Paddy' },
    { label: 'Masoor', value: 'Masoor' },
    { label: 'Soybean', value: 'Soybean' },
    { label: 'Bran', value: 'Bran' },
    { label: 'DOC', value: 'DOC' },
    { label: 'Maida', value: 'Maida' },
    { label: 'Tuar', value: 'Tuar' },
    { label: 'Flour', value: 'Flour' },
    { label: 'Chana', value: 'Chana' },
    { label: 'Moong', value: 'Moong' },
]

export const BusinessCategories = [
    { label: 'Industry', value: 'Industry' },
    { label: 'Trader', value: 'Trader' },
    { label: 'Broker', value: 'Broker' },
    { label: 'FPO', value: 'FPO' },
    { label: 'Individual', value: 'Individual' },
]


export const DeductionType = [
    { label: "Select Type", value: "" },
    { label: "Shortage", value: "Shortage" },
    { label: "Deduction", value: "Deduction" },
    { label: "Others", value: "Others" },
]