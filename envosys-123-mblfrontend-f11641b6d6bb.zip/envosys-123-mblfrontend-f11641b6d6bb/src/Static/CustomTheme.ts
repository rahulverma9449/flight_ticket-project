import { ThemeConfig } from "antd";
import colors from "../common/colors";

export const themeConfigLight: ThemeConfig = {
    components: {
        Breadcrumb: {
            separatorColor: "#919EAB",
            linkColor: colors.SecondaryColor,
            lastItemColor: colors.SecondaryColor
        },
        Button: {
            colorPrimary: colors.ThemeColor,
            colorPrimaryHover: colors.ThemeColor,
            colorPrimaryActive: colors.ThemeColor,
            colorPrimaryText: "#ffffff",
            primaryShadow: "none",
            defaultColor: "#919EAB",
            defaultBorderColor: "#919EAB",
            defaultHoverColor: colors.SecondaryColor,
            defaultBg: "white",
            paddingBlock: 5,
            paddingInline: 10,
            controlHeight: 36,
            fontWeight: 600
        },
        DatePicker: {
            activeBorderColor: colors.ThemeColor,
            hoverBorderColor: colors.ThemeColor,
            colorIcon: colors.SecondaryColor
        },
        Input: {
            colorBgBase: "#ffffff",
            hoverBorderColor: colors.ThemeColor,
            colorPrimary: "#000",
            inputFontSizeLG: 14,
            paddingBlockLG: 16,
            colorBorder: "#919EAB52",
            activeBorderColor: colors.ThemeColor,
            borderRadius: 8
        },
        Layout: {
            bodyBg: "#ffffff",
        },
        Modal: {
            colorBgMask: "rgba(0, 0, 0, 0.80)"
        },
        Radio: {
            colorBgBase: "#079782",
            colorPrimary: "#079782",
        },
        Select: {
            colorBgBase: "#fff",
            colorPrimaryHover: colors.ThemeColor,
            colorPrimaryActive: "#DDDDDD",
            optionActiveBg: "#DDDDDD",
            showArrowPaddingInlineEnd: 18
        },
        Table: {
            headerBg: "#F4F6F8",
            headerColor: "#000000",
            headerSortHoverBg: "#ebebeb",
            headerBorderRadius: 0,
            headerSplitColor: "#d3d3d3"
        },
        Tabs: {
            inkBarColor: colors.ThemeColor,
            itemSelectedColor: colors.ThemeColor,
            itemHoverColor: colors.ThemeColor
        },
        Typography: {
            titleMarginBottom: 0
        },
    },
    token: {
        colorBgContainer: "#fff",
        fontFamily: "Public Sans",
    },
}

export const themeConfigDark: ThemeConfig = {
    components: {
        Button: {
            colorPrimary: colors.ThemeColor,
            colorPrimaryHover: colors.ThemeColor,
            colorPrimaryActive: colors.ThemeColorDark,
            colorPrimaryText: "#ffffff",
            primaryShadow: "0",
            colorLink: colors.ThemeColorDark,
            colorLinkHover: colors.ThemeColorDark,
            colorLinkActive: colors.ThemeColorDark,
            defaultColor: colors.ThemeColorDark,
            defaultBorderColor: colors.ThemeColorDark,
            defaultHoverColor: colors.ThemeColorDark,
            defaultBg: "transparent",
            paddingBlock: 4,
            paddingInline: 15,
        },
        Input: {
            colorBgBase: "#ffffff",
            activeBorderColor: colors.ThemeColorDark,
            hoverBorderColor: colors.SecondaryColor,
            colorPrimary: "#000",
            activeShadow: "0",
            inputFontSizeLG: 14,
            paddingBlockLG: 10,
        },
        Select: {
            colorBgBase: "#fff",
            colorPrimaryHover: "#DDDDDD",
            colorPrimaryActive: "#DDDDDD",
            optionActiveBg: "#DDDDDD"
        },
        Radio: {
            colorBgBase: "#079782",
            colorPrimary: "#079782",
        },
        Modal: {
            colorBgMask: "rgba(0, 0, 0, 0.80)"
        },
        Table: {
            headerBg: colors.LightColorBg,
            headerColor: "#F4F6F8",
            headerSortHoverBg: "#dde4ff",
            headerBorderRadius: 0,
            headerSplitColor: "#d3d3d3"
        }
    },
    token: {
        colorBgContainer: "#fff",
        fontFamily: "Public Sans",
    },
}

export const CustomStyles = {
    // placeholderColor: "#555555",
}

