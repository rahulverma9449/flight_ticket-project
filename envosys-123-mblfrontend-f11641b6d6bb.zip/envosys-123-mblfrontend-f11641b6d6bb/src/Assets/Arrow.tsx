

type ArrowSvgProps = {
    fill: "#1890FF" | "#D9D9D9";
    orientation?: "rotated" | "normal"
}

function Arrow({ fill = "#D9D9D9", orientation = 'normal' }: ArrowSvgProps) {


    return (
        <svg xmlns="http://www.w3.org/2000/svg" width="11" height="9" viewBox="0 0 11 9" fill="none">
            {
                orientation === "normal" ?
                    <path d="M5.5 0L10.2631 8.25H0.73686L5.5 0Z" fill={fill} />
                    :
                    <path d="M5.5 9L0.73686 0.750001L10.2631 0.75L5.5 9Z" fill={fill} />
            }
        </svg>
    )
}

export default Arrow