export { default as Mail } from "@Assets/svg/Mail.svg"
export { default as User } from "@Assets/images/user.png"
export { default as ExportExcel } from "@Assets/icons/export-excel.jpg"
export { default as AddJob } from "@Assets/icons/add-job.png"
export { default as ChevronRight } from "@Assets/svg/ChevronRight.svg"
export { default as Import } from "@Assets/icons/Import.svg"
export { default as Export } from "@Assets/icons/Export.svg"

export { default as Logo } from "@Assets/images/logo.png"
export { default as LogoThumbnail } from "@Assets/images/logo-thumbnail.png"
export { default as LoginImg } from "@Assets/images/login-img.png"

export { default as oceanImport } from "@Assets/icons/oceanImport.svg"
export { default as oceanExport } from "@Assets/icons/oceanExport.svg"
export { default as airImport } from "@Assets/icons/airImport.svg"
export { default as airExport } from "@Assets/icons/airExport.svg"
export { default as tradePartner } from "@Assets/icons/tradePartner.svg"
export { default as entity } from "@Assets/icons/entity.svg"

export { default as ArrowDown } from "@Assets/icons/ArrowDown.svg"
export { default as Anchor } from "@Assets/icons/anchor.svg"
export { default as UploadImg } from "@Assets/images/upload-placeholder.png"

export { default as BasicTab } from "@Assets/icons/tabs/basic.svg"
export { default as AuditTab } from "@Assets/icons/tabs/audit.svg"
export { default as ContainerItemTab } from "@Assets/icons/tabs/container_item.svg"
export { default as DocCenterTab } from "@Assets/icons/tabs/doc-Center.svg"
export { default as NominationTab } from "@Assets/icons/tabs/NominationTab.svg"
export { default as OthersTab } from "@Assets/icons/tabs/OthersTab.svg"
export { default as PartyTab } from "@Assets/icons/tabs/PartTab.svg"


