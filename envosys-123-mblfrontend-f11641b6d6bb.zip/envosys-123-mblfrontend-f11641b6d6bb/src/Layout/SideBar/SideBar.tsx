import { useNavigate } from 'react-router-dom'
import { Menu } from 'antd';
import { AppstoreFilled } from '@ant-design/icons';
import { oceanImport, oceanExport, airImport, airExport, tradePartner, entity } from "@Assets/index";



import "./SideBar.css";

const { SubMenu } = Menu;

const items = [
    { key: '1', icon: <AppstoreFilled style={{ fontSize: "16px" }} />, label: 'Dashboard', route: '/' },
    {
        key: 'sub1',
        label: 'Ocean Import',
        icon: (
            <img src={oceanImport} alt='' />
        ),
        children: [

            // { key: '2', label: 'New Shipment', route: '/Dashboard' },
            { key: '3', label: 'Master B/L List', route: '/Ocean/Import/MBLList' },
            { key: '4', label: 'House B/L List', route: '/Dashboard' },
        ],
    },
    {
        key: 'sub2',
        label: 'Ocean Export',
        icon: (
            <img src={oceanExport} alt='' />
        ),
        children: [
            { key: '5', label: 'Master B/L List', route: '/oceanImport/mblList' },
            { key: '6', label: 'House B/L List', route: '/Dashboard' },
        ],
    },
    {
        key: 'sub3',
        label: 'Air Import',
        icon: (
            <img src={airImport} alt='' />
        ),
        children: [
            // { key: '9', label: 'Job Costing', route: '/job-costing' },
        ],
    },
    {
        key: 'sub4',
        label: 'Air Export',
        icon: (
            <img src={airExport} alt='' />
        ),
        children: [
            // { key: '9', label: 'Job Costing', route: '/job-costing' },
        ],
    },
    {
        key: 'sub5',
        label: 'Trader Partner',
        icon: (
            <img src={tradePartner} alt='' />
        ),
        children: [
            // { key: '9', label: 'Job Costing', route: '/job-costing' },
        ],
    },
    {
        key: 'sub6',
        label: 'Entity',
        icon: (
            <img src={entity} alt='' />
        ),
        children: [
            { key: '7', label: 'Agent', route: '/Dashboard' },
            { key: '8', label: 'Customer ', route: '/Dashboard' },
            { key: '9', label: 'Line ', route: '/Dashboard' },
            { key: '10', label: 'SCN ', route: '/Dashboard' },
        ],
    },

];

function SideBar() {
    const navigate = useNavigate();

    const handleClick = (route: string) => {
        navigate(route);
    };

    const renderMenuItems = (menuItems: any[]) => {
        return menuItems.map((menuItem) => {
            if (menuItem.children) {
                return (
                    <SubMenu key={menuItem.key} icon={menuItem.icon} title={menuItem.label}>
                        {renderMenuItems(menuItem.children)}
                    </SubMenu>
                );
            } else {
                return (
                    <Menu.Item key={menuItem.key} icon={menuItem.icon} onClick={() => handleClick(menuItem.route)}>
                        {menuItem.label}
                    </Menu.Item>
                );
            }
        });
    };

    return (
        <Menu defaultSelectedKeys={['1']} mode="inline" className='bg-transparent app-sidemenu'>
            {renderMenuItems(items)}
        </Menu>
    );
}

export default SideBar;