import { Outlet } from 'react-router-dom'
import TopBar from './TopBar/TopBar'
import SideBar from './SideBar/SideBar'
import { useState } from 'react';
import { Layout } from 'antd'
import './Layout.css';
import AppBreadcrumb from "@Components/AppBreadcrumb";
import { LogoThumbnail } from '@Assets/index';

const { Sider, Content } = Layout;
function AppLayout() {

    const [collapsed, setCollapsed] = useState(true);
    const collapseSider = () => {
        setCollapsed(true)
    }
    const expandSider = () => {
        setCollapsed(false)
    }

    return (
        <Layout className='h-screen main-app-screen'>
            <Sider theme='light' trigger={null} className='app-sidebar' onMouseEnter={expandSider} onMouseLeave={collapseSider} collapsible collapsed={collapsed}>
                <img src={LogoThumbnail} alt='Logo' className='width-logo' />

                {/* component with side menu options */}
                <SideBar></SideBar>
            </Sider>
            <Layout className=''>
                <TopBar />
                <Content className='bg-app p-4 main-content'>
                    <AppBreadcrumb />
                    <Outlet ></Outlet>
                    {/* <Footer>Footer</Footer> */}
                </Content>
            </Layout>
        </Layout>
    )
}

export default AppLayout