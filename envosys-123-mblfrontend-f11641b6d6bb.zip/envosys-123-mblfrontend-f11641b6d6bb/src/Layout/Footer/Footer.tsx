import AppTypography from "@Components/AppTypography"
import "./footer.css"

function Footer() {
    return (
        <footer className="px-5 py-2.5 z-10">
            <AppTypography type="Text" className="footer-text" >© 2024. All rights reserved.</AppTypography>
        </footer>
    )
}

export default Footer