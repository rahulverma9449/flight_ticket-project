import { Col, Avatar, Flex, Popover, Row, Input, Dropdown, MenuProps, } from 'antd'
import React from 'react'
import { useNavigate } from 'react-router-dom'
import AppRoute from '@Routes/AppRoute'
import { UserOutlined, BellOutlined } from '@ant-design/icons'
import GenericDropdown from "@Components/GenericDropdown";
import "./Topbar.css";
// import { context } from "../../App";
// import colors from '@Common/colors'
import colors from '../../common/colors'

const { Search } = Input;

function TopBar() {
    // const { setAppTheme } = useContext(context);
    const navigate = useNavigate()
    // const [themeColor, setThemeColor] = useState(true)

    // const viewProfile = () => {
    //     navigate(AppRoute.Profile)
    // }

    // const setThemeHandler = () => {
    //     setThemeColor(!themeColor)
    //     setAppTheme(!themeColor)
    // }

    const onSearch = (value: any, info: any) => {
        console.log(info?.source, value)
    };

    const options = [
        { label: 'Ocean Import', key: 'Ocean Import' },
        { label: 'Ocean Export', key: 'Ocean Export' },
        { label: 'Truck', key: 'Truck' },
        { label: 'Misc', key: 'Misc' },
        { label: 'WareHouse', key: 'WareHouse' },
        { label: 'AR/AP/DC', key: 'AR/AP/DC' },
        { label: 'Trade Partner', key: 'Trade Partner' },
    ];

    // Define a function to handle option selection
    const handleSelect = (key: any) => {
        console.log('Selected option:', key);
        // Add your logic here to handle the selected option
    };

    const items: MenuProps['items'] = [
        {
            label: 'Settings',
            key: '1',
        },
        {
            label: 'Profile',
            key: '2',
        },
        {
            label: (
                <a href='' onClick={() => {
                    navigate(AppRoute.Login)
                }}>Logout</a>
            ),
            key: '3',
        },
    ];

    return (
        <React.Fragment>
            <header className="px-5 py-2 shadow-sm">
                <Row align={'middle'} justify={'end'} gutter={[10, 30]}>
                    <Col>
                        <Flex justify={'space-between'} align={"center"} gap={30}>
                            <Flex className='header-search' gap={10}>
                                <GenericDropdown items={options} onSelect={handleSelect} defaultValue={"Ocean Import"} />
                                <Search placeholder="Search" className='h-full' onSearch={onSearch} />
                            </Flex>

                            {/* <Switch onClick={() => { setThemeHandler() }} checked={!themeColor} checkedChildren="Dark" unCheckedChildren="Light" /> */}

                            <Popover
                                destroyTooltipOnHide
                                placement="bottomRight"
                                title={
                                    <h3 className='text-center m-0 p-2'>
                                        Notification
                                    </h3>
                                }
                                overlayInnerStyle={{ padding: 0 }}
                                trigger="click"
                                content={
                                    <Flex vertical className="w-80">
                                        <div className="max-h-56 overflow-auto ">
                                            {/* notification */}
                                        </div>
                                        <div className="text-center">
                                            <p>Clear All</p>
                                        </div>
                                    </Flex>
                                }
                            >
                                <BellOutlined style={{ fontSize: "18px" }} />
                            </Popover>

                            <Dropdown menu={{ items }}>
                                <a onClick={(e) => e.preventDefault()}>
                                    <Avatar style={{ backgroundColor: colors.LightColorBg, verticalAlign: 'middle' }} icon={<UserOutlined style={{ color: colors.ThemeColor }} />}>
                                    </Avatar>
                                </a>
                            </Dropdown>
                        </Flex>
                    </Col>
                </Row>
            </header>
        </React.Fragment>
    )
}

export default TopBar
