export default {
    ThemeColorDark: "red",
    LightColorBg: "#f5f5f5", //light color for header, backgrounds, etc

    ThemeColor: "#303981", //dark-blue color for primary btn
    SecondaryColor: "#212B36", // dark color used for text, borders, etc
};