export default {
    AppAame: "demo",
    // App2: "demo2",
    // App3: "demo3",
    // Add more properties as needed
};