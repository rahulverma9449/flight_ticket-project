import { Iobject } from "@Types/AuxiliaryTypes";

export function getQuery(filter: Iobject) {
    const obj = {
        ...filter,
    };
    return Object.keys(obj)
        .map((key) => key + "=" + obj[key])
        .join("&");
}


export const fileType = (url: string | undefined) => {
    let type = url && url?.substr(url?.lastIndexOf('.') + 1);
    return type;
}

export function numberWithCommas(x: number | string) {
    if (x !== undefined) return x.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
    else ""
}

export function downloadExcel(res: any) {
    var byteArray = new Uint8Array(res.data);
    var blob = new Blob([byteArray], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `shipper${new Date().getUTCMilliseconds()}.xlsx`); //or any other extension
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link)
}

export const getMobileNo = (mobileNo:any) => {
    if (mobileNo && mobileNo.length >= 12) {
        let no = mobileNo.slice(mobileNo.length - 10);
        return no;
    } else {
        return mobileNo;
    }
};

/**
 * @param number 
 * @returns rounded off number if it is a number or empty string if @number contains characters 
 */
export const RoundOff = (number:any) => {
    const rounded = Math.round(number);
    if (isNaN(rounded)) {
        return "";
    }
    return rounded
}

// format number to Indian rupee
export let rupee = new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
});

export function getRupeeSymbol(amount:any) {
    if (isNaN(amount)) {
        return "";
    }
    return rupee.format(amount)
}

export function isLastIndex(array: any[], index: number) {
    return array.length - 1 === index;
}



export function roundNumber(num: number, decimalPlaces = 2) {
    let p = Math.pow(10, decimalPlaces);
    return Math.round(num * p) / p;
}