import _axios from "axios";

// Create an Axios instance
const axios = _axios.create({
    headers: {
        'Content-Type': 'application/json'
    }
});

const Base_URL = "/auth-service/auth/login"; // Relative URL

export const LOG_IN = async (data:any) => {
    try {
        console.log("api call");
        const res = await axios.post(Base_URL, data);
        console.log(res.data);
        return res.data;
        
    } catch (error:any) {
        console.log(error);
        if (error.response) {
            // Server responded with a status other than 2xx
            console.log('Error Response:', error.response.data);
        } else if (error.request) {
            // No response received
            console.log('Error Request:', error.request);
        } else {
            // Something else happened
            console.log('Error Message:', error.message);
        }
    }
}
