import { Suspense, lazy } from "react";
import { Route, Routes } from "react-router-dom";

import AppRoute from "@Routes/AppRoute";
import LoadingAnimation from "@Components/AppLoading";

const Dashboard = lazy(() => import("@Containers/Dashboard/Dashboard"));
const Login = lazy(() => import("@Containers/SignIn/Login"));
const PublicRoute = lazy(() => import("./PublicRoute/PublicRoute"));
const PrivateRoute = lazy(() => import("./PrivateRoute/PrivateRoute"));
const Layout = lazy(() => import("@Layout/Layout"));
const MblList = lazy(() => import("@Containers/MblList/MblList"));
const MblForm = lazy(() => import("@Containers/MblForm/MblForm"));

function Navigator() {
    return (
        // fallback={<LoadingAnimation />}
        <Suspense fallback={<LoadingAnimation />}>
            <Routes>
                <Route path="" element={<PublicRoute />}>
                    <Route path={AppRoute.Login} element={<Login />} />
                    {/* <Route path={AppRoute.Signup} element={<SignUp />} /> */}
                </Route>
                <Route
                    path=""
                    element={
                        <PrivateRoute>
                            <Layout />
                        </PrivateRoute>
                    }
                >
                    <Route path={AppRoute.Dashboard} element={<Dashboard />} />
                    <Route path={AppRoute.MblForm} element={<MblForm />} />
                    <Route path={AppRoute.MblList} element={<MblList />} />
                </Route>
            </Routes>
        </Suspense>
    );
}

export default Navigator;
