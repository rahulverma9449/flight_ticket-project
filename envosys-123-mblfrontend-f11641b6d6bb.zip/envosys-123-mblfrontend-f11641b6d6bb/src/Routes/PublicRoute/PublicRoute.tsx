import { Navigate, Outlet, useLocation } from 'react-router-dom';
import AppRoute from '@Routes/AppRoute';


function PublicRoute() {
    const token  = ""
    const { pathname } = useLocation();

    if (!token) {
        if (pathname === "/") return (<Navigate to={AppRoute.Login} />)
        return <Outlet></Outlet>;
    } else {
        return (<Navigate to={AppRoute.Dashboard} />)
    }

}

export default PublicRoute