
const AppRoute = {
    Login: "/login",
    Signup: "/signup",
    Kyc: "/kyc",
    Manageaddress: "/manageaddress",
    Dashboard: "/dashboard",
    AddAddress: "/addaddress",
    EditAddres: "/editaddress",
    NewShipment: "/shipment",
    Profile: "/profile",
    ActiveLoads: "/activeloads",
    DispatchAccepted: "/activeloads/accepted",
    DispatchVehicleAssigned: "/activeloads/vehicle-assigned",
    DispatchInTransit: "/activeloads/in-transit",
    DispatchPod: "/activeloads/pod",
    DispatchDueForClosure: "/activeloads/due-for-closure",
    DispatchHistory: "/activeloads/history",
    Network: "/network",
    Invites: "/invites",
    SubOrder: "/suborder",
    AboutUs: "/aboutus",
    MblForm: "/Ocean/Import/mblForm",
    MblList: "/Ocean/Import/MBLList",
    Finance: "/finance",
    DueForClosure: "/dueforclosure",
    History: "/history",
    ViewExcel: "/viewexcel"
}


export default AppRoute;