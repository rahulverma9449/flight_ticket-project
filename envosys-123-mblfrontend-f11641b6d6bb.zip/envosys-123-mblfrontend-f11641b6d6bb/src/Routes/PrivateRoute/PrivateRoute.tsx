import { Navigate } from 'react-router-dom';
import AppRoute from '@Routes/AppRoute';

type IProps = {
    children: React.ReactNode
}

function PrivateRoute({ children }: IProps) {
    const token  = "bjhb"
    if (token) {
        return children;
    } else {
        return (<Navigate to={AppRoute.Login} />)
    }
}

export default PrivateRoute