import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

import * as path from "path";

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: 'build'
  },
  server: {
    port: 3006,
    origin: "http://localhost:3006"
  },
  resolve: {
    alias: {
      "@Assets": path.resolve(__dirname, "src", "Assets"),
      "@Components": path.resolve(__dirname, "src", "Components"),
      "@Static": path.resolve(__dirname, "src", "Static"),
      "@Containers": path.resolve(__dirname, "src", "Containers"),
      "@Layout": path.resolve(__dirname, "src", "Layout"),
      "@Types": path.resolve(__dirname, "src", "Types"),
      "@Api": path.resolve(__dirname, "src", "Api"),
      "@Routes": path.resolve(__dirname, "src", "Routes"),
      "@Hooks": path.resolve(__dirname, "src", "Hooks"),
      "@Redux": path.resolve(__dirname, "src", "Redux"),
      "@Enum": path.resolve(__dirname, "src", "Enum"),
      "@Utils": path.resolve(__dirname, "src", "Utils"),
    },
  },
});
